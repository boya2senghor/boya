/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Fjcomp_Treshold;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;

/**
 *
 * @author Administrateur
 */
public class DivConqMatrixMulti {
    static int processor;
    static int treshold;
    static int n;
   // static int[][] result;
    public DivConqMatrixMulti(int n){
        this.n=n;
       // this.result=result;

    }
    void initialize(int[][]a, int aij[][],int x, int  y,int n){
            for(int i=0;i<n/2;i++)
            for(int j=0;j<n/2;j++){
                aij[i][j]=a[x+i][y+j];
            }
    }

    int [][]add(int[][]a1,int[][]b1){
        int N=a1.length;
        //System.out.println("length "+N);
        int M=a1[0].length;
        int [][]c1=new int [N][M];
        for(int i=0;i<a1.length;i++){
            for(int j=0;j<a1[i].length;j++){
                c1[i][j]=a1[i][j]+b1[i][j];
               // System.out.println("Hi");
                //=a1[i][j]+b1[i][j];
            }
        }
        return c1;
    }

    void putTogether(int aij[][],int[][]a,int x, int  y,int n){
       /*
        for(int i=x;i<x+n/2;i++)
            for(int j=y;j<y+n/2;i++){
                a[i][j]=aij[i][j];
            }
        */

        for(int i=0;i<n/2;i++)
            for(int j=0;j<n/2;j++){
                a[i+x][j+y]=aij[i][j];
            }
    }

 int[][] divideandconq(int[][]a, int b[][],int[][]result1,int n)
 {
// int nthreads=8;
     int nthreads=processor;
 ForkJoinPool pool=new ForkJoinPool (nthreads);
divideandconqImpl adivideandconqImpl=new divideandconqImpl (a,b,result1,n);
 pool.invoke(adivideandconqImpl);
 return adivideandconqImpl.result;
 }
 private class divideandconqImpl extends RecursiveAction {
 private int [ ] [ ] a;
 private int [ ] [ ] b;
 private int [ ] [ ] result1;
 private int n;
 private  int [ ] [ ] result;
 private divideandconqImpl(int [ ] [ ] a,int [ ] [ ] b,int [ ] [ ] result1,int n){
 this.a=a;
 this.b=b;
 this.result1=result1;
 this.n=n;
 }
 protected void compute(){
 //if(n<=96){
     if(n<=treshold){
 result= divideandconq(a,b,result1,n);
 } else{
        //int [][] result=new int[];
       // System.out.println("Hello "+n);
      if (n == 1) {
           result1[0][0] = a[0][0] * b[0][0];



        }
        else {
            int[][] a11 = new int[n/2][n/2];
            int[][] a12 = new int[n/2][n/2];
            int[][] a21 = new int[n/2][n/2];
            int[][] a22 = new int[n/2][n/2];
            int[][] b11 = new int[n/2][n/2];
            int[][] b12 = new int[n/2][n/2];
            int[][] b21 = new int[n/2][n/2];
            int[][] b22 = new int[n/2][n/2];

            initialize(a, a11, 0 , 0,n);
            initialize(a, a12, 0 , n/2,n);
            initialize(a, a21, n/2, 0,n);
            initialize(a, a22, n/2, n/2,n);
            initialize(b, b11, 0 , 0,n);
            initialize(b, b12, 0 , n/2,n);
            initialize(b, b21, n/2, 0,n);
            initialize(b, b22, n/2, n/2,n);

		int[][] res1;
		int[][] res2;
		int[][] res3;
		int[][] res4;
		int[][] res5;
		int[][] res6;
		int[][] res7;
		int[][] res8;
 divideandconqImpl task1 =null ;
 divideandconqImpl task2 =null ;
 divideandconqImpl task3 =null ;
 divideandconqImpl task4 =null ;
 divideandconqImpl task5 =null ;
 divideandconqImpl task6 =null ;
 divideandconqImpl task7 =null ;
 divideandconqImpl task8 =null ;
 task1 =new divideandconqImpl(a11, b11,result1,n/2);
 task2 =new divideandconqImpl(a12, b21,result1,n/2);
 task3 =new divideandconqImpl(a11, b12,result1,n/2);
 task4 =new divideandconqImpl(a12, b22,result1,n/2);
 task5 =new divideandconqImpl(a21, b11,result1,n/2);
 task6 =new divideandconqImpl(a22, b21,result1,n/2);
 task7 =new divideandconqImpl(a21, b12,result1,n/2);
 task8 =new divideandconqImpl(a22, b22,result1,n/2);
 invokeAll(task1,task2,task3,task4,task5,task6,task7,task8);
 res1= task1.result;
 res2= task2.result;
 res3= task3.result;
 res4= task4.result;
 res5= task5.result;
 res6= task6.result;
 res7= task7.result;
 res8= task8.result;

            int[][] c11 = add(res1,res2);
            int[][] c12 = add(res3,res4);
            int[][] c21 = add(res5, res6);
            int[][] c22 = add(res7,res8 );

            putTogether(c11, result1, 0 , 0, n);
            putTogether(c12, result1, 0 , n/2,n);
            putTogether(c21, result1, n/2, 0,n);
            putTogether(c22, result1, n/2, n/2,n);
        }
        result= result1;
 }
 }
 private
 int[][] divideandconq(int[][]a, int b[][],int[][]result1,int n){
        //int [][] result=new int[];
       // System.out.println("Hello "+n);
      if (n == 1) {
           result1[0][0] = a[0][0] * b[0][0];



        }
        else {
            int[][] a11 = new int[n/2][n/2];
            int[][] a12 = new int[n/2][n/2];
            int[][] a21 = new int[n/2][n/2];
            int[][] a22 = new int[n/2][n/2];
            int[][] b11 = new int[n/2][n/2];
            int[][] b12 = new int[n/2][n/2];
            int[][] b21 = new int[n/2][n/2];
            int[][] b22 = new int[n/2][n/2];

            initialize(a, a11, 0 , 0,n);
            initialize(a, a12, 0 , n/2,n);
            initialize(a, a21, n/2, 0,n);
            initialize(a, a22, n/2, n/2,n);
            initialize(b, b11, 0 , 0,n);
            initialize(b, b12, 0 , n/2,n);
            initialize(b, b21, n/2, 0,n);
            initialize(b, b22, n/2, n/2,n);

		int[][] res1;
		int[][] res2;
		int[][] res3;
		int[][] res4;
		int[][] res5;
		int[][] res6;
		int[][] res7;
		int[][] res8;

	   //taskq nthreads=2 if(n==4)
	   {
            //task
		res1=divideandconq(a11, b11,result1,n/2);
		//task
            res2=divideandconq(a12, b21,result1,n/2);
		//task
            res3=divideandconq(a11, b12,result1,n/2);
		//task
            res4=divideandconq(a12, b22,result1,n/2);
		//task
            res5=divideandconq(a21, b11,result1,n/2);
		//task
           	res6=divideandconq(a22, b21,result1,n/2);
		//task
            res7=divideandconq(a21, b12,result1,n/2);
		//task
            res8=divideandconq(a22, b22,result1,n/2);
          }

            int[][] c11 = add(res1,res2);
            int[][] c12 = add(res3,res4);
            int[][] c21 = add(res5, res6);
            int[][] c22 = add(res7,res8 );

            putTogether(c11, result1, 0 , 0, n);
            putTogether(c12, result1, 0 , n/2,n);
            putTogether(c21, result1, n/2, 0,n);
            putTogether(c22, result1, n/2, n/2,n);
        }
        return result1;
}
 }


    public static void main(String args[]){
        //int N=32;
        int N=Integer.parseInt(args[0]);
        processor=Integer.parseInt(args[1]);
        treshold=Integer.parseInt(args[2]);
         int[][] result_=new int[N][N];
         int[][] a=new int[N][N];

        DivConqMatrixMulti m=new DivConqMatrixMulti(N);


         for(int i=0;i<N;i++)
                    for(int j=0;j<N;j++){
                        a[i][j]=4;
                    }

        StopWatch stopWatch = new StopWatch();
        int[][] result1=m.divideandconq(a, a,result_, N);
        stopWatch.stop();
         System.out.println("Parallel Matrix Product with threshold parameter Elapsed Time: " + stopWatch.getElapsedTime());
        /*
         System.out.println("Matrix = ");
		for (int i = 0; i < N; i++)
			for (int j = 0; j < N; j++)
			{
				System.out.print(result1[i][j] + " ");
				if (j == (N-1))
					System.out.println();
			}
         */
         




    }




}
