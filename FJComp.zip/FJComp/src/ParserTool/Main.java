package ParserTool;
import java.io.*;

public class Main {
    static FileReader in;
    static File tempFile;
    static PrintStream tempOutput;
    //Ajout:
    static StringBuffer pre1 = new StringBuffer("");
    static Object obj = new Object();
    public static void main(String args[]) throws FileNotFoundException {
        String fileName = args[0];
        //Renommer le nouveau fichier
        fileName = fileName.replace(".tmp", ".java");
        in = new FileReader(args[0]);
        tempFile = new File(fileName);
        tempOutput = new PrintStream(tempFile);
        // JavaParser p = new JavaParser(System.in);
        JavaParser p = new JavaParser(in);
        try {
            ASTCompilationUnit cu = p.CompilationUnit();
            tempOutput.println("/*************************************************************************");
            tempOutput.println("*   Ce code est généré et mis en forme par le compilateur FJComp         *");
            tempOutput.println("* Auteur du Compilateur: Abdourahmane Senghor  -- boya2senghor@yahoo.fr  *");
            tempOutput.println("**************************************************************************/");
            tempOutput.println("\n");
            print((SimpleNode) cu, pre1, obj);
            System.err.println("Bravo! Parallelisation reussie. \nCode parallele genere et mis en forme.");
        } catch (Exception e) {
            System.err.println("Desole, erreur survenue. Echec de la Parallelisation");
            System.err.println(e.getMessage());
            e.printStackTrace();
        }
    }
   
    static int counter = 0;
    public static Object print(SimpleNode node, StringBuffer pre, Object data) {
        Token t = node.jjtGetFirstToken();
        while (t != node.jjtGetLastToken()) {           
            if (t.toString().compareTo("for") == 0) {
                print(pre, t, node);
                t = t.next;
                while (t.toString().compareTo(")") != 0) {
                    print(t);
                    t = t.next;
                }
            }
            //fin ajout
            if (t.toString().compareTo("{") == 0) {
                counter = counter + 1;
                pre = preStr(counter, pre);                
                print(pre, t, node);
            } else {
                pre = preStr(counter, pre);                
                print(pre, t, node);
            }
            t = t.next;
        }
        // if (t.toString().compareTo("{")==0) pre.append("   ");
        if (t.toString().compareTo("{") == 0) //pre.append("   ");
        {
            counter = counter + 1;
            pre = preStr(counter, pre);            
            print(pre, t, node);
        } else {
            pre = preStr(counter, pre);            
            print(pre, t, node);
        }
        return data;
    }

    protected static void print(StringBuffer pre, Token t, SimpleNode node) {
        Token tt = t.specialToken;
        if (tt != null) {
            while (tt.specialToken != null) {
                tt.specialToken.image = "";
                tt = tt.specialToken;
            }
        }
        String s = t.image.trim();
        if (t.toString().compareTo(";") == 0) {
            if (t.next.toString().compareTo("}") == 0) {
                counter = counter - 1;
                pre = preStr(counter, pre);
            }
            t.image = s + "\n" + pre;
        } else if (t.toString().compareTo("{") == 0) {
            if (t.next.toString().compareTo("}") == 0) {
                counter = counter - 1;
                pre = preStr(counter, pre);
            }
            t.image = s + "\n" + pre;
        } else if (t.toString().compareTo("}") == 0) {
            if (t.next.toString().compareTo("}") == 0) {
                counter = counter - 1;
                pre = preStr(counter, pre);
            }
            t.image = s + "\n" + pre;
        } else {
            t.image = s + " ";
        }      
        tempOutput.print(addUnicodeEscapes(t.image));
    }

    public static StringBuffer preStr(int x, StringBuffer pre1) {
        pre1 = new StringBuffer("");
        for (int i = 1; i <= x; i++) {
            pre1.append("   ");
        }
        return pre1;
    }

    protected static void print(Token t) {
        Token tt = t.specialToken;
        if (tt != null) {
            while (tt.specialToken != null) {
                tt = tt.specialToken;
            }
            while (tt != null) {                
                tempOutput.print(" ");
                tt = tt.next;
            }
        }        
        tempOutput.print(addUnicodeEscapes(t.image));
    }

    private static String addUnicodeEscapes(String str) {
        String retval = "";
        char ch;
        for (int i = 0; i < str.length(); i++) {
            ch = str.charAt(i);
            if ((ch < 0x20 || ch > 0x7e) &&
                    ch != '\t' && ch != '\n' && ch != '\r' && ch != '\f') {
                String s = "0000" + Integer.toString(ch, 16);
                retval += "\\u" + s.substring(s.length() - 4, s.length());
            } else {
                retval += ch;
            }
        }
        return retval;
    }
    //Fin Ajout:
}
