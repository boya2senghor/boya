/* Copyright (c) 2006, Sun Microsystems, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Sun Microsystems, Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */


package FJCompCompiler;

import java.io.PrintStream;
import java.util.LinkedList;
import java.util.Stack;

public class AddAcceptVisitor extends UnparseVisitor
{
  //permet de verifier la presence de //taskq annotation
  boolean isFjcompAnnotationPresent=false;
  //permet de verifier la declaration de package
  boolean isPackageDeclarationPresent=false;
  //permet de verifier la declaration de import
  boolean isImportationDeclarationPresent=false;
  //permet de declarer de la liste qui sert a contenir les declarartions des imports generes par le compilateur FJComp
  LinkedList FJComp_Imporation_List=new LinkedList();
  //permet de declarer la liste qui sert a contenir la copie de l'entête de la method recursive
  LinkedList<String> FIFOforOriginalHeadOfMethodDeclarationCopy=new LinkedList();
  //permet de declarer la liste qui sert a contenir la copie des modifiers de la method recursive sans les modifiers
  LinkedList<String> FIFOforOriginalModifierOfMethodDeclarationCopy=new LinkedList();
//permet de declarer la liste qui sert a contenir la copie de la method recursive sans les modifiers
  LinkedList<String> FIFOforOriginalBlockOfMethodDeclarationCopy=new LinkedList();
   //Sert à contenir la valeur  de : MaxDepth=<value>
  LinkedList<String> FIFOforValueofMaxDepth=new LinkedList();;
   //Sert à contenir l'expression conditionnelle de treshold
  LinkedList<String> FIFOforExpressionofTreshold=new LinkedList();;
  //sert à contenir la valeur de nthreads=<value>
  LinkedList<String> FIFOforValueofNthreads=new LinkedList();;
  SymbolTable tableParInv=new SymbolTable();; // it contains  symbols like formal parameters
  //sert a contenir les arguments de la methode recursive
  LinkedList<String> myStatckForArgumentOfMethodSerial=new LinkedList();
  //sert à contenir les types des parametres de la methode recursive qui seront utilisés pour déclarer les champs dans la nouvelle classe
  LinkedList<String> myStatckForFieldDeclarationType=new LinkedList();
  //sert à contenir les noms des parametres de la methode recursive qui seront utilisés pour déclarer les champs dans la nouvelle classe
  LinkedList<String> myStatckForFieldDeclarationName=new LinkedList();
  //sert à contenir les methodes invoquées
  LinkedList<String> FIFOforMethodInvocation=new LinkedList();
  //sert à contenir les arguments des  methodes invoquées
  LinkedList<String> FIFOforMethodInvocationArguments=new LinkedList();
  //sert à contenir les résultats des  methodes invoquées
  LinkedList<String> FIFOforMethodInvocationResult=new LinkedList();
  //sert à contenir les variables contenant les valeurs retournées par la methode
  LinkedList<String> FIFOforResultOfTask=new LinkedList();
  //sert à contenir les déclarations des tasks
  LinkedList<String> FIFOforTaskDeclaration=new LinkedList();
  //sert à contenir la valeur de l'index des tasks lors de la déclaration des tasks
  int indexOfTask=1;
  //sert à contenir la valeur de l'index des tasks lors de l'initiation des tasks
  int indexOfTask_=1;

 

  public AddAcceptVisitor(PrintStream o)
  {
    super(o);
  }

  public  Object visit(ASTFJCompAnnotation node, Object data){
           
      /*
      if ((data.toString().compareTo("false"))==0){
          isFjcompAnnotationPresent=true;
      }
        */
      SimpleNode astmethoddeclaration=(SimpleNode)node.jjtGetParent();
      String methodDeclarationName="";

      String value="7";
      if ((data.toString().compareTo("false"))==0){
          Token t= node.firstToken;

          while(t.image.compareTo("jreVersion")!=0){
              t=t.next;
          }
          if(t.image.compareTo("jreVersion")==0){
              value=t.next.next.image;
          }
          //parcourir tous les noeuds fils
          /*
          for(int i=0;i<node.jjtGetNumChildren();i++){
              System.out.println("Number of Children: "+node.jjtGetNumChildren());
              //Tester si le noeud fils correspond a la clause version et recueillir la valeur de la version (5 ou 6 ou 7)
              System.out.println("Children Node :"+((SimpleNode)node.jjtGetChild(i)).jjtGetFirstToken().image);
              if(((SimpleNode)node.jjtGetChild(i)).jjtGetFirstToken().image.compareTo("jreVersion")==0){
                   value=((SimpleNode)node.jjtGetChild(i)).jjtGetFirstToken().next.next.image;
                   System.out.println("value: "+ value);
              }
          }*/
          //  Peremier Etape: Tester la version de la JRE
          if (value.toString().compareTo("5")==0 || value.toString().compareTo("6")==0){
              FJComp_Imporation_List.add("import jsr166y.forkjoin.ForkJoinPool;");
              FJComp_Imporation_List.add("import jsr166y.forkjoin.RecursiveAction;");              
          }
          else if (value.toString().compareTo("7")==0){
              FJComp_Imporation_List.add("import java.util.concurrent.ForkJoinPool;");
              FJComp_Imporation_List.add("import java.util.concurrent.RecursiveAction;");
          }
          else{
            System.out.println("A wrong value of jre Version");
            System.exit(1);
          }

          //Deuxieme Etape: Copier la method Originale
          //*****Début Copy of the original method*****************//
           //Detremnining the method declaration node
          //SimpleNode astmethoddeclaration=(SimpleNode)node.jjtGetParent();
            while(astmethoddeclaration.id!=JavaParserTreeConstants.JJTMETHODDECLARATION ){
               astmethoddeclaration=(SimpleNode)astmethoddeclaration.jjtGetParent();
           }

         SimpleNode astclassorinterfacebodydeclaration=(SimpleNode)node.jjtGetParent();
          while(astclassorinterfacebodydeclaration.id!=JavaParserTreeConstants.JJTCLASSORINTERFACEBODYDECLARATION ){
              astclassorinterfacebodydeclaration=(SimpleNode)astclassorinterfacebodydeclaration.jjtGetParent();
          }
          for(int i=0;i<astclassorinterfacebodydeclaration.jjtGetNumChildren();i++){
               if(astmethoddeclaration==astclassorinterfacebodydeclaration.jjtGetChild(i)) {
                    try{
                        super.myprintOriginalNodeCopy((SimpleNode)astclassorinterfacebodydeclaration.jjtGetChild(i-1),FIFOforOriginalModifierOfMethodDeclarationCopy);
                        for(int j=0;j<astmethoddeclaration.jjtGetNumChildren();j++){
                            if(((SimpleNode)astmethoddeclaration.jjtGetChild(j)).id==JavaParserTreeConstants.JJTBLOCK){
                                 super.myprintOriginalNodeCopy((SimpleNode)astmethoddeclaration.jjtGetChild(j),FIFOforOriginalBlockOfMethodDeclarationCopy);
                                break;
                            }
                            super.myprintOriginalNodeCopy((SimpleNode)astmethoddeclaration.jjtGetChild(j),FIFOforOriginalHeadOfMethodDeclarationCopy);
                        }
                      
                    }
                    catch(Exception e){System.out.println("Erreur:"+e.getMessage());
                    }
                    
                }
          }
       //Fin Copy Original method

         //Début récupération de la valeur de nthreads=<value>
          super.myprintNumThread((SimpleNode)node, FIFOforValueofNthreads);
          //Fin récupération de la valeur de nthreads=<value>
        //Début récupération de la valeur de MaxDepth=<value>
          super.myprintMaxDepth((SimpleNode)node, FIFOforValueofMaxDepth);
        //Fin récupération de la valeur de MaxDepth=<value>
           //Début récupération de l'expression conditionnelle de treshold
          SimpleNode tresholdNode=(SimpleNode)node.jjtGetChild(0);
          if(((SimpleNode)tresholdNode).id==JavaParserTreeConstants.JJTFJCOMPOPTIONLIST)
          for(int i=0;i<tresholdNode.jjtGetNumChildren();i++){
              
          if(((SimpleNode)tresholdNode.jjtGetChild(i).jjtGetChild(0)).id==JavaParserTreeConstants.JJTTRESHOLD){
            tresholdNode=(SimpleNode)tresholdNode.jjtGetChild(i).jjtGetChild(0);
             //System.out.println("Bébé");
             super.myprintTreshold((SimpleNode)tresholdNode, FIFOforExpressionofTreshold);
            break;
          }
          }
         


         
         
             //Début détermination du  nom de la methode
          // String methodDeclarationName="";
           for(int i=0;i<astmethoddeclaration.jjtGetNumChildren();i++){
               if(((SimpleNode)astmethoddeclaration.jjtGetChild(i)).id==JavaParserTreeConstants.JJTMETHODDECLARATOR)
               {
                   methodDeclarationName=((SimpleNode)astmethoddeclaration.jjtGetChild(i)).jjtGetFirstToken().image;
                   break;
               }
           
           }          
          System.out.println(methodDeclarationName);
           //Fin détermination du  nom de la methode
          print(node,data);
          }



      if ((data.toString().compareTo("true"))==0){
          //out.print("\n task1;");
          //Afficher les déclarations des tasks
          while(!FIFOforTaskDeclaration.isEmpty()){
            out.print("\n "+FIFOforTaskDeclaration.pop());
          }
          int i=node.jjtGetNumChildren()-1;
          //Afficher le dernier noeud
          for(int j=0;j<((SimpleNode)node.jjtGetChild(i)).jjtGetNumChildren();j++)
          {
            print((SimpleNode)node.jjtGetChild(i).jjtGetChild(j),data);
          }
          out.print("\n invokeAll(task1,task2);");
          //afficher: [var]=task1.result; ...
          while(!FIFOforResultOfTask.isEmpty()){
            out.print("\n "+FIFOforResultOfTask.pop());
          }
          //print((SimpleNode)node.jjtGetChild(i),data);


          
      }
        

      


       

     //print(node,data);
      return data;

  }


  
  public Object visit(ASTModifiers node, Object data){
      Token t= node.jjtGetFirstToken();
      
      //if ((data.toString().compareTo("true"))==0) print(t);
      //out.print(t.image);

        if ((data.toString().compareTo("true"))==0)
      try{
          while (t.kind==JavaParserConstants.PUBLIC || t.kind==JavaParserConstants.STATIC
                  || t.kind==JavaParserConstants.PROTECTED || t.kind==JavaParserConstants.PRIVATE
                  || t.kind==JavaParserConstants.FINAL || t.kind==JavaParserConstants.ABSTRACT
                  || t.kind==JavaParserConstants.SYNCHRONIZED || t.kind==JavaParserConstants.NATIVE
                  || t.kind==JavaParserConstants.TRANSIENT || t.kind==JavaParserConstants.VOLATILE
                  || t.kind==JavaParserConstants.STRICTFP)
          {
               print(t);

               //if(t.kind!=JavaParserConstants.PUBLIC && t.kind!=JavaParserConstants.STATIC)
                 //  break;
               t=t.next;

          }
          // print(t);
         // out.print(t.image);
      
      }catch(Exception e){ e.printStackTrace();}
      
      
      return data;
  }
   
   

  public Object visit(ASTImportDeclaration node, Object data){
      isImportationDeclarationPresent=true;
      print(node, data);
       if ((data.toString().compareTo("true"))==0 ) {                  
           while(!FJComp_Imporation_List.isEmpty()){
            out.println("");
            out.print(FJComp_Imporation_List.pop());
           }
           
       }
      //Autoriser ecriture au deuxieme parse et tester si
      /*
      System.out.println("Hi");
      if ((data.toString().compareTo("true"))==0 ){
          print(node, data);
          if (isFjcompAnnotationPresent==true){
              out.println("import jsr166y.forkjoin.ForkJoinPool;");
              out.println("import jsr166y.forkjoin.RecursiveAction;");
          }
          
      }
      */

      return data;

  }

  public Object visit(ASTPackageDeclaration node, Object data){
      isPackageDeclarationPresent=true;
       print(node, data);
      if ((data.toString().compareTo("true"))==0 ) {         
          //Si dans le fichier original, import n'est pas déclaré, alors
          //ajouter les declarations de import generes par FJCOMP apres la declaration de package
          //import jsr166y.forkjoin.ForkJoinPool; import java.util.concurrent.RecursiveAction; pour jre=5 ou 6
          //import java.util.concurrent.ForkJoinPool; import java.util.concurrent.RecursiveAction; pour jre=7
          if(!isImportationDeclarationPresent){
            while(!FJComp_Imporation_List.isEmpty()){
            //out.println("");
            out.print("\n" +FJComp_Imporation_List.pop());
           }
          }
      }
      return data;
  }

  /*
public Object visit(ASTClassOrInterfaceBodyDeclaration node, Object data){
    if ((data.toString().compareTo("true"))==0 ) {
    //Si dans le fichier original, import et package ne sont  pas déclarés, alors
    //ajouter les declarations de import generes par FJCOMP juste avant la declaration de la classe
       while(!FJComp_Imporation_List.isEmpty()){
            //out.println("");
            out.print("\n" +FJComp_Imporation_List.pop());
        }
        print(node,data);
    }
    return data;

}
*/


  public Object visit(ASTTypeDeclaration node, Object data){

    if ((data.toString().compareTo("true"))==0 ) {
        //out.println("HI Here");
    //Si dans le fichier original, import et package ne sont  pas déclarés, alors
    //ajouter les declarations de import generes par FJCOMP juste avant la declaration de la classe
       if (!isImportationDeclarationPresent && !isPackageDeclarationPresent)
        while(!FJComp_Imporation_List.isEmpty()){
            //out.println("");
            out.print("\n" +FJComp_Imporation_List.pop());
        }
        
    }
    print(node,data);
    return data;
}

 
  public Object visit(ASTMethodDeclaration node, Object data){

     // if ((data.toString().compareTo("true"))==0 ) {
    //D'abord nous affichons le contenu de la méthode courante
    //tableParInv.addScope();
      if ((data.toString().compareTo("false"))==0 ) {
    data=print(node, data);
      }
    //tableParInv.killScope();
      //}
     

       //Tout Ce qui suit vient juste apres le contenu de la methode courante

       if ((data.toString().compareTo("true"))==0 ) {
           
             //Début détermination du  nom de la methode
           tableParInv.addScope();
        // data=print(node, data);
           String methodDeclarationName="";
           for(int i=0;i<node.jjtGetNumChildren();i++){
               if(((SimpleNode)node.jjtGetChild(i)).id==JavaParserTreeConstants.JJTMETHODDECLARATOR)
               {
                   methodDeclarationName=((SimpleNode)node.jjtGetChild(i)).jjtGetFirstToken().image;
                   break;
               }

           }

           //Début Détermination du type retourné par la methode
           String resultTypeName="";
           for(int i=0;i<node.jjtGetNumChildren();i++){
               if(((SimpleNode)node.jjtGetChild(i)).id==JavaParserTreeConstants.JJTRESULTTYPE)
               {
                   try{
                   Token t=((ASTResultType)node.jjtGetChild(i)).jjtGetFirstToken();
                   //resultTypeName=t.image;
                   //t=t.next;
                   while(t!=((ASTResultType)node.jjtGetChild(i)).jjtGetLastToken()){

                   
                   resultTypeName=resultTypeName + " "+t.image;
                   t=t.next;
                   }
                   resultTypeName=resultTypeName + " "+t.image;
                    break;
                   }catch(Exception e){
                       break;

                   }
                  
               }
           }
           //Fin Détermination du type retourné par la methode

           //Parcourir toute la méthode, puis remplacer return par result=
           Token t_=node.jjtGetFirstToken();
           if(resultTypeName.compareTo("void")!=0)
           while(t_!=node.jjtGetLastToken()){
             if(t_.image.compareTo("return")==0) {
                 t_.image="result=";
                 System.out.println("Hello How are you");
                 //break;
             }
             t_=t_.next;
           }
           int lastIndex=node.jjtGetNumChildren()-1;
           for(int i=0;i<=lastIndex-1;i++) print((SimpleNode)node.jjtGetChild(i),data);
           //out.print("\n protected void compute()");
           //Début du block de la déclaration de méthode
           out.print("{");
           if(!FIFOforValueofMaxDepth.isEmpty())
           out.print("\n if (maxdepth>="+FIFOforValueofMaxDepth.getFirst()+"){");
           else if(!FIFOforExpressionofTreshold.isEmpty()){
               out.print("\n");
           while(!FIFOforExpressionofTreshold.isEmpty()){
               out.print(FIFOforExpressionofTreshold.pop());
           }
               out.print("{");
          }
           else{
                out.print("\n if (maxdepth>=3){");
           }
           //Ecrire : invoquer fonction séquentielle:  result=fibonacci(n);
           //System.out.println("Resultype1: "+resultTypeName);
           if(resultTypeName.trim().compareTo("void")!=0)
            out.print("\n result=");
           else out.print("\n");
            out.print(methodDeclarationName+"(" );

             //Nous affichons les arguments de la méthode courante
              //**Début Détermination  Determination of the arguments
            Stack<String>  myStatckForArgumentOfMethodSerial_=new Stack();

            tableParInv.getInit();            //Initialize the symbol table
              SymbolTable.Symbol symbol_;
                            //Here, we push all symbols we need into various stacks
              try
                  {
                        do
                        {
                              symbol_=tableParInv.getNext();   //Get the next symbol of the Symbol table

                             myStatckForArgumentOfMethodSerial_.push(symbol_.name);

                        } while(true);
                    }
                   catch(Exception e)
                    {

                    }

               try
            {
                String elt_myFifoForArgumentOfMethod_=myStatckForArgumentOfMethodSerial_.pop();
                out.print(elt_myFifoForArgumentOfMethod_);
                do
                {

                    elt_myFifoForArgumentOfMethod_=myStatckForArgumentOfMethodSerial_.pop();

                    out.print( ","+elt_myFifoForArgumentOfMethod_);

                 } while(true);
            }
            catch(Exception e)
            {

             }


           out.print(");");
          //

           out.print("\n } else{");
           for(int i=0;i<node.jjtGetChild(lastIndex).jjtGetNumChildren();i++)
               print((SimpleNode)node.jjtGetChild(lastIndex).jjtGetChild(i),data);
          // if(!FIFOforValueofMaxDepth.isEmpty())
           //Fin du bloc de else
           out.print("\n }");
           
           //Fin du block de la déclaration de méthode
           out.print("\n }");
          //data=print(node, data);

       //**Start writing into the outputfile the following code:
           
           //Début écrirure :
           ///[Modifiers]  Type MethodName([FormalParamters])
            ///{
               ///int nthreads=<int>;
               ///ForkJoinPool pool=new ForkJoinPool (nthreads);
               ///[MethodName]Impl a[MethodName]Impl=new [MethodName]Impl ([arguments]);
            ///}
           out.print("\n");
           //while(!FIFOforOriginalModifierOfMethodDeclarationCopy.isEmpty()) {
               for(int i=0;i<FIFOforOriginalModifierOfMethodDeclarationCopy.size();i++){
         String elt_FIFOforOriginalModifierOfMethodDeclarationCopy=FIFOforOriginalModifierOfMethodDeclarationCopy.get(i);
         out.print(elt_FIFOforOriginalModifierOfMethodDeclarationCopy);
         }
         //while(!FIFOforOriginalHeadOfMethodDeclarationCopy.isEmpty()) {
             for(int i=0;i<FIFOforOriginalHeadOfMethodDeclarationCopy.size();i++){
         String elt_FIFOforOriginalHeadOfMethodDeclarationCopy=FIFOforOriginalHeadOfMethodDeclarationCopy.get(i);
         out.print(elt_FIFOforOriginalHeadOfMethodDeclarationCopy);
         }
           out.print("\n {");
           //Début écriture:  int nthreads=<int>;
             out.print("\n int nthreads=");
             try{
                 //Ecrire la valeur specifie par l'utilisateur
                 out.print(FIFOforValueofNthreads.pop() +";");
             }catch(Exception e){
                 //Si la clause nthreads n'est pas préciser alors ecrire: Runtime.getRuntime().availableProcessors();
                 out.print("Runtime.getRuntime().availableProcessors();");
             }
             // Début écriture : ForkJoinPool pool=new ForkJoinPool (nthreads);
             out.print("\n ForkJoinPool pool=new ForkJoinPool (nthreads);");
             // Fin écriture ForkJoinPool pool=new ForkJoinPool (nthreads);
            //Début écriture:  [MethodName]Impl a[MethodName]Impl=new [MethodName]Impl ([formalParameters]);
             out.print("\n"+methodDeclarationName+"Impl "+"a"+methodDeclarationName+"Impl");
             out.print("=new "+methodDeclarationName+"Impl (");
             
             //Nous affichons les arguments de la méthode courante
              //**Début Détermination  Determination of the arguments
            tableParInv.getInit();            //Initialize the symbol table
              SymbolTable.Symbol symbol;
                            //Here, we push all symbols we need into various stacks
              try
                  {
                        do
                        {
                              symbol=tableParInv.getNext();   //Get the next symbol of the Symbol table
                              
                              myStatckForArgumentOfMethodSerial.push(symbol.name);
                              myStatckForFieldDeclarationType.push(symbol.sig );
                              myStatckForFieldDeclarationName.push(symbol.name );
                        } while(true);
                    }
                   catch(Exception e)
                    {
                      
                    }

              //Au cas ou MaxDepth=<value> est spécifiié par l'utilisateur:
             //Début écriture de la valeur de maxdetph
              try{
                 //Ecrire la valeur specifie par l'utilisateur
                 if(myStatckForArgumentOfMethodSerial.isEmpty()){
                    out.print(FIFOforValueofMaxDepth.getFirst() );
                 }else{
                    out.print(FIFOforValueofMaxDepth.getFirst() +",");
                 }

             }catch(Exception e){}
             //Fin écriture de la valeur de maxdetph

              try
            {
                String elt_myFifoForArgumentOfMethod=myStatckForArgumentOfMethodSerial.pop();
                out.print(elt_myFifoForArgumentOfMethod);
                do
                {

                    elt_myFifoForArgumentOfMethod=myStatckForArgumentOfMethodSerial.pop();

                    out.print( ","+elt_myFifoForArgumentOfMethod);

                 } while(true);
            }
            catch(Exception e)
            {
              
             }
               //**Fin Détermination  Determination of the arguments
              out.print(");");
           //Fin écriture:  [MethodName]Impl a[MethodName]Impl=new [MethodName]Impl ([formalParameters]);
             // Début écriture : pool.invoke(a[MethodName]Impl);
              out.print("\n pool.invoke("+"a"+methodDeclarationName+"Impl);");
             // Fin écriture : pool.invoke(a[MethodName]Impl);
              // Si la methode retourne alors
                //Début écriture : return a[MethodName]Impl.result
              System.out.println("ResultTypeName: "+resultTypeName);
                 if(resultTypeName.compareTo("void")!=0)
                       out.print("\n return a"+methodDeclarationName+"Impl.result;");
                //Fin écriture : return a[MethodName]Impl.result
              out.print("\n }");

        //Début Ecriture: private class [MethodName]Impl extends RecursiveAction {...}
          out.print("\n private class "+methodDeclarationName+"Impl extends RecursiveAction {");
          // Début Ecriture de: declaration du champ maxdepth si la clause maxdepth est spécifiées

                if(!FIFOforValueofMaxDepth.isEmpty()){
             out.print("\n private int maxdepth;");
             }
          // Fin Ecriture de: declaration du champ maxdepth si la clause maxdepth est spécifiées

          //Début écriture : déclarations des champs qui ne sont rien d'autre que les arguments de la méthode
          //try{
              for(int i=0;i<myStatckForFieldDeclarationType.size();i++){
          //while(!myStatckForFieldDeclarationType.isEmpty() ){
              //out.print("\n private "+myStatckForFieldDeclarationType.pop()+" "+myStatckForFieldDeclarationName.pop()+";");
                  out.print("\n private "+myStatckForFieldDeclarationType.get(i)+" "+myStatckForFieldDeclarationName.get(i)+";");
          }
         // }
          //catch(Exception e){
          //}
          //Début Ecriture de : declaration du champ result si la methode retourne
           if(resultTypeName.compareTo("void")!=0){
           out.print("\n private "+resultTypeName+ " result;");
           }
          //Fin Ecriture de : declaration du champ result si la methode retourne

          

          //Début écriture: déclaration du constructeur: private [MethodName]Impl([int maxdepth],[formalParameters]){...}
          //Début écriture: déclaration de l'entete du constructeur
          out.print("\n private "+methodDeclarationName+"Impl(");
          //Debut Ecriture des parametres du constructeur
          if(!FIFOforValueofMaxDepth.isEmpty()){
          try{
                 //Ecrire la valeur specifie par l'utilisateur
                 if(myStatckForFieldDeclarationType.isEmpty()){
                    out.print(" int maxdepth" );
                 }else{
                    out.print(" int maxdepth,");
                 }

             }catch(Exception e){}
          }
          //}
          //if(!FIFOforValueofMaxDepth.isEmpty()){
            // out.print(" int maxdepth");
             //}
             try{
             out.print(myStatckForFieldDeclarationType.get(0)+" "+myStatckForFieldDeclarationName.get(0));
           for(int i=1;i<myStatckForFieldDeclarationType.size();i++){
                  out.print(","+myStatckForFieldDeclarationType.get(i)+" "+myStatckForFieldDeclarationName.get(i));
          }
             }
             catch(Exception e){}
            out.print("){");
            //Fin écriture: déclaration de l'entete du constructeur
            //Début écriture: contenu de déclaration du constructeur
            //this.maxdepth=maxdepth;
            if(!FIFOforValueofMaxDepth.isEmpty()){                  
                    out.print("\n this.maxdepth=maxdepth;" );
            }

             try{
             //out.print(myStatckForFieldDeclarationType.get(0)+" "+myStatckForFieldDeclarationName.get(0));
           for(int i=0;i<myStatckForFieldDeclarationType.size();i++){
                  out.print("\n this."+myStatckForFieldDeclarationName.get(i)+"=" +myStatckForFieldDeclarationName.get(i)+";");
          }
             }
             catch(Exception e){}
            out.print("\n }");
            //Fin écriture: contenu de déclaration du constructeur
           //Fin écriture: déclaration du constructeur:

       //Début écriture de la méthode originale
             boolean isEmptyModifier=true;

             for(int i=0;i<FIFOforOriginalModifierOfMethodDeclarationCopy.size();i++){
                  String elt_FIFOforOriginalModifierOfMethodDeclarationCopy=FIFOforOriginalModifierOfMethodDeclarationCopy.get(i);
               if(elt_FIFOforOriginalModifierOfMethodDeclarationCopy.compareTo("public")==0
                 ||elt_FIFOforOriginalModifierOfMethodDeclarationCopy.compareTo("protected")==0
                 ||elt_FIFOforOriginalModifierOfMethodDeclarationCopy.compareTo("private")==0){
             isEmptyModifier=false;
           
         }
             }
             System.out.println("isEmptyModifier: "+isEmptyModifier);
             /*if(isEmptyModifier){

                 out.print("private ");
            
         }
             */

            for(int i=0;i<FIFOforOriginalModifierOfMethodDeclarationCopy.size();i++){
                
         String elt_FIFOforOriginalModifierOfMethodDeclarationCopy=FIFOforOriginalModifierOfMethodDeclarationCopy.get(i);
         if(isEmptyModifier && i==0){
            elt_FIFOforOriginalModifierOfMethodDeclarationCopy=" private "+elt_FIFOforOriginalModifierOfMethodDeclarationCopy;
         }
         if(elt_FIFOforOriginalModifierOfMethodDeclarationCopy.compareTo("public")==0
                 ||elt_FIFOforOriginalModifierOfMethodDeclarationCopy.compareTo("protected")==0
                 ||elt_FIFOforOriginalModifierOfMethodDeclarationCopy.compareTo("private")==0)
             elt_FIFOforOriginalModifierOfMethodDeclarationCopy="private";
         out.print(elt_FIFOforOriginalModifierOfMethodDeclarationCopy);
         }
         //while(!FIFOforOriginalHeadOfMethodDeclarationCopy.isEmpty()) {
             for(int i=0;i<FIFOforOriginalHeadOfMethodDeclarationCopy.size();i++){
         String elt_FIFOforOriginalHeadOfMethodDeclarationCopy=FIFOforOriginalHeadOfMethodDeclarationCopy.get(i);
         out.print(elt_FIFOforOriginalHeadOfMethodDeclarationCopy);
         }
         for(int i=0;i<FIFOforOriginalBlockOfMethodDeclarationCopy.size();i++){
         String elt_FIFOforOriginalBlockOfMethodDeclarationCopy=FIFOforOriginalBlockOfMethodDeclarationCopy.get(i);
         out.print(elt_FIFOforOriginalBlockOfMethodDeclarationCopy);
         }


        //Fin écriture de la méthode originale

          out.print("\n }");
       //Fin Ecriture: private class [MethodName]Impl extends RecursiveAction {...}
             tableParInv.killScope();
       //**End determination of the arguments of SER_MyMethod(...)
               
       }

     
    return data;
  }
 
/*****Track the formal parameters of the parallel multiway recursive method************************/
/*******We use the symbol table for this******************************************************/
public Object visit(ASTFormalParameter astformalparameter, Object obj)
{

       if ((obj.toString().compareTo("true"))==0 ) {

         ASTType asttype = (ASTType)astformalparameter.jjtGetChild(1); //this node denotes the type of the formalparameter
        //SimpleNode asttype = (SimpleNode)astformalparameter.jjtGetChild(1); //this node denotes the type of the formalparameter
        ASTVariableDeclaratorId astvariabledeclaratorid = (ASTVariableDeclaratorId)astformalparameter.jjtGetChild(2); //this node denotes the variable name of the formal parameter
        //SimpleNode astvariabledeclaratorid = (SimpleNode)astformalparameter.jjtGetChild(2); //this node denotes the variable name of the formal parameter
        String s = ((SimpleNode)astformalparameter.jjtGetChild(2)).jjtGetFirstToken().toString(); //s1 string correponds to the  name of the variable of th
        String s1 = "";
        Token token = asttype.jjtGetFirstToken();  //the first token of astype node
        do
        {
            s1 = s1 + " " + token.toString();
            if(token == asttype.jjtGetLastToken())
            {
                break;
            }
            token = token.next;
        } while(true);
        for(Token token1 = astvariabledeclaratorid.jjtGetFirstToken(); token1 != astvariabledeclaratorid.jjtGetLastToken();)
        {
            token1 = token1.next;
            s1 = s1 + " " + token1.toString();
        }
        System.out.println(s1);
   SymbolTable.Symbol symbolParInv = tableParInv.addSymbol(s);
    symbolParInv.sig = s1.trim();
   
    symbolParInv.isInitialized = false;


       }
        print(astformalparameter,obj);
    return obj;
}
  

 public Object visit(ASTFJCompStatement node, Object data){
      SimpleNode astmethoddeclaration=(SimpleNode)node.jjtGetParent();
      String methodDeclarationName="";
     
     //System.out.println("Baby");
            if ((data.toString().compareTo("false"))==0){

            }
           if ((data.toString().compareTo("true"))==0){


           System.out.println("Hello"+methodDeclarationName);

           while(astmethoddeclaration.id!=JavaParserTreeConstants.JJTMETHODDECLARATION ){
               astmethoddeclaration=(SimpleNode)astmethoddeclaration.jjtGetParent();
           }

           for(int i=0;i<astmethoddeclaration.jjtGetNumChildren();i++){
               if(((SimpleNode)astmethoddeclaration.jjtGetChild(i)).id==JavaParserTreeConstants.JJTMETHODDECLARATOR)
               {
                   methodDeclarationName=((SimpleNode)astmethoddeclaration.jjtGetChild(i)).jjtGetFirstToken().image;
                   break;
               }

           }

          //Rechercher la méthode invoquée
          Token t=node.jjtGetFirstToken();
          while(t!=node.jjtGetLastToken()){
              if(t.image.compareTo(methodDeclarationName)==0) {
                 // t.image="Hello";
                  out.println(t.image);
              }else print(t);
              System.out.println(t.image);
              t=t.next;
      }

      }
     return data;

 }
  public Object visit(ASTFJCompTask node, Object data) {
      
            SimpleNode astmethoddeclaration=(SimpleNode)node.jjtGetParent();
            String methodDeclarationName="";

           while(astmethoddeclaration.id!=JavaParserTreeConstants.JJTMETHODDECLARATION ){
               astmethoddeclaration=(SimpleNode)astmethoddeclaration.jjtGetParent();
           }

           for(int i=0;i<astmethoddeclaration.jjtGetNumChildren();i++){
               if(((SimpleNode)astmethoddeclaration.jjtGetChild(i)).id==JavaParserTreeConstants.JJTMETHODDECLARATOR)
               {
                   methodDeclarationName=((SimpleNode)astmethoddeclaration.jjtGetChild(i)).jjtGetFirstToken().image;
                   break;
               }

           }
       if(data.toString().compareTo("false")==0){
           FIFOforTaskDeclaration.add(methodDeclarationName+"Impl task"+indexOfTask+" =null ;");
           indexOfTask++;
       }

      if(data.toString().compareTo("true")==0){
          //Début écrire: [MethodName]Impl task1=new [MethodName]Impl([Arguments]);

      out.print("\n task"+indexOfTask_+" =new "+ methodDeclarationName+"Impl");
      indexOfTask_++;
      //Token t=((ASTFJCompTask)node.jjtGetChild(1)).jjtGetFirstToken();
      out.print("(");
      if(!FIFOforValueofMaxDepth.isEmpty()){
          out.print("maxdepth+1,");
      }
      print((SimpleNode)node.jjtGetChild(1).jjtGetChild(0),data);
      out.print(")");
      out.print(";");
      Token t=node.jjtGetFirstToken();
      if(t.next.next.image.compareTo("=")==0){
          FIFOforResultOfTask.add(t.next.image+"= task1.result;");

      }

      }
         return data;
         //print(node, data);
    }
  

//  public Object visit(ASTClassOrInterfaceBodyDeclaration node, Object data)
 // {
    /*
      //Are we the first child of our parent?
    if (node == node.jjtGetParent().jjtGetChild(0)) {

      //Attempt to make the new code match the indentation of thenode.
      StringBuffer pre = new StringBuffer("");
      for (int i = 1; i < node.jjtGetFirstToken().beginColumn; ++i) {
	pre.append(' ');
      }

      out.println(pre + "");
      out.println(pre + "// Accept the visitor. ");
      out.println(pre + "public Object jjtAccept(JavaParserVisitor visitor, Object data) {");
      out.println(pre + "  return visitor.visit(this, data);");
      out.println(pre + "}");
    }*/
   // return super.visit(node, data);
  //}





}
