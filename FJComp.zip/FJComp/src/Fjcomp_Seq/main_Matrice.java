/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Fjcomp_Seq;

//import Seq_Matrice.*;

/**
 *
 * @author zing
 */
public class main_Matrice extends Matrice {


     public int[][] Matrice(int[][]a,int[][]b, int M,int N,int K){
        //int M=end-start+1;
        int c[][]=new int[M][K];
        for(int i=0; i<M; i++)
            for(int  j=0; j<K; j++)
                for  (int p=0; p<N; p++){
                    c[i][j]+= a[i][p]*b[p][j];
                }
        //System.out.println(Thread.currentThread().getName()+"  "+ Thread.currentThread().getState()+"  a fini");
        return c;
    }




    public static void main(String args[]){
        /*int M=Integer.parseInt(args[0]);
        int N=Integer.parseInt(args[1]);
        int K= Integer.parseInt(args[2]);
          */
        int M,N,K;
                M=N=K=1024;
        int a[][]=new int[M][N];
        int b[][]=new int[N][K];
        int c[][]=new int[M][K];
        int start=0;
        int end=M-1;
        
        for (int i=start;i<=end;i++)
            for(int j=0;j<N;j++)
                a[i][j]=5;
        for (int i=0;i<N;i++)
            for(int j=0;j<K;j++)
                b[i][j]=5;
       //Initialiser la matrice c
        for(int i=0;i<M;i++)
            for(int j=0;j<K;j++)
                c[i][j]=0;
        main_Matrice matrix=new main_Matrice();
        long t0=System.currentTimeMillis();
        System.err.println(" start at "+(System.currentTimeMillis()-t0));
        c=matrix.Matrice(a,b,M,N,K);
        System.err.println(" start at "+(System.currentTimeMillis()-t0));
       
        for(int i=start;i<=end;i++){
           
            for (int j=0;j<K;j++){
                System.out.print(" "+c[i-start][j]+" ");
            }
            System.out.println();
        }
        

    }

}
