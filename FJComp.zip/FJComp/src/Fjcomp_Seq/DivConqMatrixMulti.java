/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Fjcomp_Seq;

/**
 *
 * @author Administrateur
 */
public class DivConqMatrixMulti {
    static int n;
   // static int[][] result;
    public DivConqMatrixMulti(int n){
        this.n=n;
       // this.result=result;

    }
    void initialize(int[][]a, int aij[][],int x, int  y,int n){
            for(int i=0;i<n/2;i++)
            for(int j=0;j<n/2;j++){
                aij[i][j]=a[x+i][y+j];
            }
    }

    int [][]add(int[][]a1,int[][]b1){
        int N=a1.length;
        //System.out.println("length "+N);
        int M=a1[0].length;
        int [][]c1=new int [N][M];
        //for(int i=0;i<a1.length;i++){
        for(int i=0;i<N;i++){
            //for(int j=0;j<a1[i].length;j++){
               for(int j=0;j<M;j++){
                c1[i][j]=a1[i][j]+b1[i][j];
               // System.out.println("Hi");
                //=a1[i][j]+b1[i][j];
            }
        }
        return c1;
    }

    void putTogether(int aij[][],int[][]a,int x, int  y,int n){
       /*
        for(int i=x;i<x+n/2;i++)
            for(int j=y;j<y+n/2;i++){
                a[i][j]=aij[i][j];
            }
        */

        for(int i=0;i<n/2;i++)
            for(int j=0;j<n/2;j++){
                a[i+x][j+y]=aij[i][j];
            }
        
    }
 int[][] divideandconq(int[][]a, int b[][],int[][]result1,int n){
        //int [][] result=new int[];
       // System.out.println("Hello "+n);
      if (n == 1) {
           result1[0][0] = a[0][0] * b[0][0];
           
          

        }
        else {
            int[][] a11 = new int[n/2][n/2];
            int[][] a12 = new int[n/2][n/2];
            int[][] a21 = new int[n/2][n/2];
            int[][] a22 = new int[n/2][n/2];
            int[][] b11 = new int[n/2][n/2];
            int[][] b12 = new int[n/2][n/2];
            int[][] b21 = new int[n/2][n/2];
            int[][] b22 = new int[n/2][n/2];
            

            initialize(a, a11, 0 , 0,n);
            initialize(a, a12, 0 , n/2,n);
            initialize(a, a21, n/2, 0,n);
            initialize(a, a22, n/2, n/2,n);
            initialize(b, b11, 0 , 0,n);
            initialize(b, b12, 0 , n/2,n);
            initialize(b, b21, n/2, 0,n);
            initialize(b, b22, n/2, n/2,n);
		
		int[][] res1;
		int[][] res2;
		int[][] res3;
		int[][] res4;
		int[][] res5;
		int[][] res6;
		int[][] res7;
		int[][] res8;

	   //taskq nthreads=2 MaxDepth=1
	   {
            //task
		res1=divideandconq(a11, b11,result1,n/2);
		//task
            res2=divideandconq(a12, b21,result1,n/2);
		//task
            res3=divideandconq(a11, b12,result1,n/2);
		//task
            res4=divideandconq(a12, b22,result1,n/2);
		//task
            res5=divideandconq(a21, b11,result1,n/2);
		//task
           	res6=divideandconq(a22, b21,result1,n/2);
		//task
            res7=divideandconq(a21, b12,result1,n/2);
		//task
              res8=divideandconq(a22, b22,result1,n/2);
          }  
          
            int[][] c11 = add(res1,res2);
            int[][] c12 = add(res3,res4);
            int[][] c21 = add(res5, res6);
           int[][] c22 = add(res7,res8 );
            

            putTogether(c11, result1, 0 , 0, n);
            putTogether(c12, result1, 0 , n/2,n);
            putTogether(c21, result1, n/2, 0,n);
            putTogether(c22, result1, n/2, n/2,n);
           
        }
        return result1;
}


    public static void main(String args[]){
        int N=512;
      //  int N=Integer.parseInt(args[0]);
         int[][] result_=new int[N][N];
         int[][] a=new int[N][N];

        DivConqMatrixMulti m=new DivConqMatrixMulti(N);


         for(int i=0;i<N;i++)
                    for(int j=0;j<N;j++){
                        a[i][j]=5;
                    }
         StopWatch stopWatch = new StopWatch();
        int[][] result1=m.divideandconq(a, a,result_, N);
        stopWatch.stop();
         System.out.println("Sequential Matrix Product Elapsed Time: " + stopWatch.getElapsedTime());
        
        /*
         System.out.println("Matrix = ");
		for (int i = 0; i < N; i++)
			for (int j = 0; j < N; j++)
			{
				System.out.print(result1[i][j] + " ");
				if (j == (N-1))
					System.out.println();
			}
         */
         
    }





}
