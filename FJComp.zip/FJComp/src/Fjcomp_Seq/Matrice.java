/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Fjcomp_Seq;

//import Seq_Matrice.*;

/**
 *
 * @author zing
 */
public class Matrice {

  /* public int[][] Matrice(int[][]a,int[][]b,int start,int end, int N,int K){
        int M=end-start+1;
        int c[][]=new int[M][K];
        for(int i=start; i<=end; i++)
            for(int  j=0; j<K; j++)
                for  (int p=0; p<N; p++){
                    c[i-start][j]+= a[i][p]*b[p][j];                    
                }
        //System.out.println(Thread.currentThread().getName()+"  "+ Thread.currentThread().getState()+"  a fini");
        return c;
    }*/

   public int[][] Matrice(int[][]a,int[][]b, int M,int N,int K){
        //int M=end-start+1;
        int c[][]=new int[M][K];
        for(int i=0; i<M; i++)
            for(int  j=0; j<K; j++)
                for  (int p=0; p<N; p++){
                    c[i][j]+= a[i][p]*b[p][j];
                }
        //System.out.println(Thread.currentThread().getName()+"  "+ Thread.currentThread().getState()+"  a fini");
        return c;
    }

}
