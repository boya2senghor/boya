/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Fjcomp_Seq;



/**
 *
 * @author Administrateur
 */
public class StopWatch {
    long startTime;
    long stopTime;
    
    public StopWatch(){
        startTime = System.currentTimeMillis();

    }
    public void stop(){
        stopTime = System.currentTimeMillis();

    }

    public long getElapsedTime(){
        return stopTime - startTime;

    }
    
       // System.out.println("Fibonnaci de "+n+"  "+fib(n));
       //long stopTime = System.currentTimeMillis();
    //long elapsedTime = stopTime - startTime;

}
