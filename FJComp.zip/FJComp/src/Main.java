/* Copyright (c) 2006, Sun Microsystems, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Sun Microsystems, Inc. nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */


package FJCompCompiler;
//import ParserTool.*;
import java.io.*;


public class Main 
{

    static FileReader in;
    static File tempFile;
    static  PrintStream tempOutput;

    //Ajout:
    static StringBuffer pre1=new StringBuffer("");
    static Object obj=new Object();
    
  public static void main(String args[]) throws FileNotFoundException {
      String  fileName=args[0];      
       fileName=fileName.replace(".tmp", ".java");
        in=new FileReader(args[0]);

     tempFile =new File(fileName);
     tempOutput= new PrintStream(tempFile);   
    System.err.println("Reading from standard input...");
  // JavaParser p = new JavaParser(System.in);
    System.out.println("Salut First");
     JavaParser p = new JavaParser(in);
      
    try {
         //  System.out.println("Salut");
       ASTCompilationUnit cu = p.CompilationUnit();
    
       tempOutput.println("/*******************************");
       tempOutput.println("**Author: Abdourahmane Senghor**");
       tempOutput.println("**email: boya2senghor@yahoo.fr**");
       tempOutput.println("********************************/");
       tempOutput.println("\n\n");
       print((SimpleNode)cu,pre1,obj);
       System.err.println("Thank you.");
    } catch (Exception e) {
      System.err.println("Oops.");
      System.err.println(e.getMessage());
      e.printStackTrace();
    }
  }

  //Debut Ajout:
 static int counter=0;
  public static Object print(SimpleNode node, StringBuffer pre,Object data)
{

    Token t = node.jjtGetFirstToken();
    while (t != node.jjtGetLastToken()){
        //j'ai ajouté
        if(t.toString().compareTo("for")==0) {
            print(pre,t,node);
            t=t.next;
            while(t.toString().compareTo(")")!=0){
                print(t);
                t=t.next;
            }
    }

        //fin ajout
        if (t.toString().compareTo("{")==0) {
            counter=counter+1;
            pre=preStr(counter,pre);
            //print(pre,t);
            print(pre,t,node);


        }else{
        pre=preStr(counter,pre);
        //print(pre,t);
         print(pre,t,node);
        }
        t=t.next;
    }
    // if (t.toString().compareTo("{")==0) pre.append("   ");
    if (t.toString().compareTo("{")==0) //pre.append("   ");
    {
        counter=counter+1;
        pre=preStr(counter,pre);
            //print(pre,t);
         print(pre,t,node);
    }

    else{
    pre=preStr(counter,pre);
     //print(pre,t);
     print(pre,t,node);
    }
    return data;

}


  protected static void print(StringBuffer pre, Token t, SimpleNode node) {
     Token tt = t.specialToken;
     if (tt != null) {
      while (tt.specialToken != null)
      {
          tt.specialToken.image="";
          tt = tt.specialToken;
      }
    }
      String s=t.image.trim();

      if(t.toString().compareTo(";")==0){
          if(t.next.toString().compareTo("}")==0) {
              counter=counter-1;
              pre=preStr(counter,pre);
          }
          t.image=s+"\n"+pre;          
      }else
      if(t.toString().compareTo("{")==0){
          if(t.next.toString().compareTo("}")==0) {
              counter=counter-1;
              pre=preStr(counter,pre);
          }
          t.image=s+"\n"+pre;

      }
      else
      if(t.toString().compareTo("}")==0){
          if(t.next.toString().compareTo("}")==0) {
              counter=counter-1;
              pre=preStr(counter,pre);
          }
          t.image=s+"\n"+pre;
      }
      else t.image=s+" ";
    //tempOutput1.print(addUnicodeEscapes(t.image));
      tempOutput.print(addUnicodeEscapes(t.image));
   }

  public static StringBuffer preStr(int x, StringBuffer pre1)
  {
    pre1=new StringBuffer("");
    for(int i=1;i<=x;i++) pre1.append("   ");
    return pre1;
  }

   protected static void print(Token t) {
    Token tt = t.specialToken;
    if (tt != null) {
      while (tt.specialToken != null) tt = tt.specialToken;
      while (tt != null) {       
        //tempOutput1.print(" ");
          tempOutput.print(" ");
        tt = tt.next;
      }
    }
    //tempOutput1.print(addUnicodeEscapes(t.image));
    tempOutput.print(addUnicodeEscapes(t.image));
  }

  private static String addUnicodeEscapes(String str) {
    String retval = "";
    char ch;
    for (int i = 0; i < str.length(); i++) {
      ch = str.charAt(i);
      if ((ch < 0x20 || ch > 0x7e) &&
	  ch != '\t' && ch != '\n' && ch != '\r' && ch != '\f') {
  	String s = "0000" + Integer.toString(ch, 16);
  	retval += "\\u" + s.substring(s.length() - 4, s.length());
      } else {
        retval += ch;
      }
    }
    return retval;
  }
  //Fin Ajout:
}
