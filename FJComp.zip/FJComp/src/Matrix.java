/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Concurrencer_Seq;

/**
 *
 * @author Administrateur
 */
import java.util.Random;


public class Matrix
{
	int[][] m, o;
	int n;
	long begin, end;
	double classicTime, recursiveTime;
	Random r = new Random();
	//Scanner in = new Scanner(System.in);

	public Matrix(int n)
	{
		m = new int[n][n];
		o = new int[n][n];
		this.n = n;
		//generateRandom();
               for(int i=0;i<n;i++)
                    for(int j=0;j<n;j++){
                        m[i][j]=2;
                    }
	}

	public void display()
	{
		System.out.println("Matrix = ");
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
			{
				System.out.print(m[i][j] + " ");
				if (j == (n-1))
					System.out.println();
			}

	}

	private void generateRandom()
	{
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				m[i][j] = Math.abs(r.nextInt()) % 10;

	}

	public Matrix classicMultiply(Matrix b)
	{
		int[][] c = new int[n][n];
		begin = System.currentTimeMillis();

		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				for (int k = 0; k < n; k++)
					c[i][k] += m[i][j] * b.m[j][k];

		end = System.currentTimeMillis();
		classicTime = (end - begin)/1000.0;
		Matrix C = new Matrix(n);
		C.m = c;

		return C;
	}
	public Matrix recursiveMultiply(Matrix b)
	{
		begin = System.currentTimeMillis();
		divConquer(n, 0, 0, m, b.m);
		end = System.currentTimeMillis();
		recursiveTime = (end - begin)/1000.0;
		Matrix D = new Matrix(n);
		D.m = o;

		return D;
	}

	public int divConquer(int n, int i, int j, int[][] ar1, int[][] ar2)
	{
		if (n == 1) //{ return ar[i][j]; }
                {
                    return ar1[i][j]*ar1[i][j];
                   // o[i][j+1]=ar1[i][j+1];
                    //return ar1[i][j];//*ar2[0][0];
                }

		else
		{
                    

                        o[i][j] = divConquer(n/2, i, j, ar1, ar2)*divConquer(n/2, i, j, ar1, ar2) + divConquer(n/2, i, j + (n/2), ar1, ar2)*divConquer(n/2, i + (n/2), j, ar1, ar2);
			o[i][j+1] = divConquer(n/2, i, j, ar1, ar2)*divConquer(n/2, i, j + (n/2), ar1, ar2) + divConquer(n/2, i, j + (n/2), ar1, ar2)*divConquer(n/2, i + (n/2), j + (n/2), ar1, ar2);
			o[i+1][j] = divConquer(n/2, i + (n/2), j, ar1, ar2)*divConquer(n/2, i, j, ar1, ar2) + divConquer(n/2, i + (n/2), j + (n/2),ar1, ar2)*divConquer(n/2, i + (n/2), j, ar1, ar2);
			o[i+1][j+1] = divConquer(n/2, i + (n/2), j, ar1, ar2)*divConquer(n/2, i, j + (n/2), ar1, ar2) + divConquer(n/2, i + (n/2), j + (n/2), ar1, ar2 )*divConquer(n/2, i + (n/2), j + (n/2), ar1, ar2);
                        
                   


                    /*int res1= divConquer(n/2, i, j, ar1, ar2);
                     int res2=divConquer(n/2, i, j + (n/2), ar1, ar2);
                     int res3=divConquer(n/2, i + (n/2), j, ar1, ar2);

                     int res4=divConquer(n/2, i + (n/2), j + (n/2), ar1, ar2);

                     o[i][j]=res1*res1+res2*res3;
                     o[i][j+1]=res1*res2+res2*res4;
                     o[i+1][j]=res3*res1+res4*res3;
                     o[i+1][j+1]=res3*res2+res4*res4;
                     */
                        return 1;

		}
		
	}

	/*
	public void divConquer(int n, int i, int j, int[][] ar1, ar2)
	{
		if (n == 2)
		{
			o[i][j] = [i][j]*ar1, ar2[i][j] + [i][j+1]*ar1, ar2[i+1][j];

			o[i][j+1] = [i][j]*ar1, ar2[i][j+1] + [i][j+1]*ar1, ar2[i+1][j+1];

			o[i+1][j] = [i+1][j]*ar1, ar2[i][j] + [i+1][j+1]*ar1, ar2[i+1][j];

			o[i+1][j+1] = [i+1][j]*ar1, ar2[i][j+1] + [i+1][j+1]*ar1, ar2[i+1][j+1];

		}
		else
		{
			divConquer(n/2, i, j, );
			divConquer(n/2, i, j + (n/2), );
			divConquer(n/2, i + (n/2), j, );
			divConquer(n/2, i + (n/2), j + (n/2), );

		}

	}
	*/

       

}


