package FJCompCompiler;

import java.io.*;

public class FJComp {
    //For reading file
    static FileReader in;
    //File
    static File tempFile;
    //output file Streaming
    static PrintStream tempOutput;
    //For deleting the directives constructs
    static FileReader in1;
    static File tempFile1;
    static PrintStream tempOutput1;
    public static void main(String args[])  {       
        String fileName[] = new String[1];
        try{
        //args[0] est le premier fichier, celui fourni en entréé par l'utilisateur
        fileName[0] = args[0];
        //Renommer le nouveau Fichier
        fileName[0] = fileName[0].replace(".fj", ".bak");
        if(fileName[0].compareTo(args[0])==0) {
            System.out.println("Message d'Erreur:" +
                   "\nFichier d'extension differente de .fj" +
                   "\nVeuillez specifier un fichier existant d'extension .fj " +
                   "\nEchec de la Parallelisation");
           System.exit(1);
        }
        //Pour permettre à FJComp de lire le premier fichier (.fj)
        in = new FileReader(args[0]); 
        //Pour permettre à FJComp d'écrire sur le nouveau fichier (.bak)
        tempFile = new File(fileName[0]);   
        //Streaming pour écrire sur le nouveau fichier (.bak)
        tempOutput = new PrintStream(tempFile);
       }catch( Exception e){
           System.out.println("Message d'Erreur:" +
                   "\nFichier specifie introuvable" +
                   "\nVeuillez specifier un fichier existant d'extension .fj " +
                   "\nEchec de la Parallelisation");
           System.exit(1);
       }
        System.err.println("Lecture du fichier source...");        
        JavaParser p = new JavaParser(in);
        try {
            ASTCompilationUnit cu = p.CompilationUnit();          
            JavaParserVisitor visitor = (JavaParserVisitor) new AddAcceptVisitor(tempOutput);            
            //Parcourir le programme et visiter tous les noeuds, mais ne pas écrire sur le fichier
            cu.jjtAccept(visitor, false);
            //Parcourir le programme et visiter tous les noeuds et écrire sur le nouveau fichier (.bak)
            cu.jjtAccept(visitor, true);           
        } catch (ParseException e) {
            /*
            System.out.println("Message d'Erreur:" +
                   "\nFichier d'extension differente de .fj" +
                   "\nVeuillez specifier un fichier existant d'extension .fj " +
                   "\nEchec de la Parallelisation");
             */
            /*
            System.out.println("Message d'Erreur:" +
                    "\n Verifier la syntaxe")*/
            System.out.println(e.getMessage());
            System.out.println("Echec de la Parallelisation");
            //e.printStackTrace();
            System.exit(1);
        }
        //Fin de génération du fichier .bak qui contient le block de //taskq
        //Début Génération du fichier .tmp pour supprimmer "{" et "}" du block de taskq
        String fileName_[] = new String[1];
        try{
        //Renommer le nouveau Fichier
        fileName_[0] = fileName[0].replace(".bak", ".tmp");
        //Pour permettre à FJComp de lire le  fichier (.bak)
        in1 = new FileReader(fileName[0]);
        //Pour permettre à FJComp d'écrire sur le nouveau fichier (.tmp)
        tempFile1 = new File(fileName_[0]);   //FJcomp write to this file
        //Streaming pour écrire sur le nouveau fichier (.tmp)
        tempOutput1 = new PrintStream(tempFile1);
        }catch(Exception e){
        }
        JavaParser p1 = new JavaParser(in1);
        try {
            ASTCompilationUnit cu1 = p1.CompilationUnit();
            JavaParserVisitor visitor1 = (JavaParserVisitor) new DeleteDirective(tempOutput1);
            //Parcourir le programme et visiter tous les noeuds et écrire sur le nouveau fichier (.tmp)
            cu1.jjtAccept(visitor1, true);
        } catch (Exception e) {
            System.err.println("Message d'erreur: ");
            System.out.println("Erreur de Parsing");
            System.exit(1);
        }
        //Formatage du Fichier generé par FJCOMP
        //Invocation de l'outil de formatage
        try{
        ParserTool.Main.main(fileName_);
        }catch(Exception e){
            System.err.println("Message d'erreur: ");
            System.out.println("Erreur de Parsing");
            System.exit(1);
        }
        //Fermer le flux
        tempOutput.close();
        //Supprimer le fichier .bak
        tempFile.delete();
        //Fermer le flux
        tempOutput1.close();
        //Supprimer le fichier .tmp
        tempFile1.delete();

    }
}
