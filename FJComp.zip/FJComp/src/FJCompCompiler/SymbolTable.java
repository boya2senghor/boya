// Decompiled by DJ v3.11.11.95 Copyright 2009 Atanas Neshkov  Date: 21/08/2011 12:47:04
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   SymbolTable.java

//package jomp.compiler;
package FJCompCompiler;
import java.io.PrintStream;

public class SymbolTable
{
    public static class Symbol
    {

        private boolean isNewScope;
        private Symbol prev;
        public String name;
        public String sig;
        public boolean isInitialized;





        public Symbol()
        {
            isNewScope = false;
            name = null;
            sig = null;
            isInitialized = false;
        }
    }


    Symbol wp;
    private Symbol currentSymbol;

    public SymbolTable()
    {
        currentSymbol = new Symbol();
        currentSymbol.isNewScope = true;
    }

    public Symbol addSymbol(String s)
    {
        Symbol symbol = new Symbol();
        symbol.prev = currentSymbol;
        currentSymbol = symbol;
        currentSymbol.name = s;
        return currentSymbol;
    }

    public Symbol findSymbol(String s)
    {
        for(Symbol symbol = currentSymbol; symbol != null; symbol = symbol.prev)
            if(!symbol.isNewScope && symbol.name.compareTo(s) == 0)
                return symbol;

        return null;
    }

    public void getInit()
    {
        wp = new Symbol();
        wp.prev = currentSymbol;
    }

    public Symbol getNext()
    {
        while(wp.prev != null) 
        {
            wp = wp.prev;
            if(!wp.isNewScope)
                return wp;
        }
        return null;
    }

    public void addScope()
    {
        Symbol symbol = new Symbol();
        symbol.prev = currentSymbol;
        currentSymbol = symbol;
        currentSymbol.isNewScope = true;
    }

    public void killScope()
    {
        try
        {
            for(; !currentSymbol.isNewScope; currentSymbol = currentSymbol.prev);
            currentSymbol = currentSymbol.prev;
        }
        catch(NullPointerException nullpointerexception)
        {
            System.err.println("SymbolTable stack underflow!");
            return;
        }
    }

    public void dumpTable()
    {
        Symbol symbol = currentSymbol;
        System.err.println("----------------------------------------");
        for(; symbol != null; symbol = symbol.prev)
            if(symbol.isNewScope)
                System.err.println("NEW SCOPE");
            else
                System.err.println(symbol.sig + " " + symbol.name);

        System.err.println("----------------------------------------");
    }

    
}