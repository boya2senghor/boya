package FJCompCompiler;

import java.io.PrintStream;
import java.util.LinkedList;
import java.util.Stack;

public class AddAcceptVisitor extends UnparseVisitor {
   //permet de verifier la declaration de package
    boolean isPackageDeclarationPresent = false;
    //permet de verifier la declaration de import
    boolean isImportationDeclarationPresent = false;
    //permet de declarer de la liste qui sert a contenir les declarartions des imports generes par le compilateur FJComp
    LinkedList FJComp_Imporation_List = new LinkedList();
    //permet de declarer la liste qui sert a contenir la copie de l'entête de la method recursive
    LinkedList<String> FIFOforOriginalHeadOfMethodDeclarationCopy = new LinkedList();
    LinkedList<LinkedList<String>> FIFOofFIFOforOriginalHeadOfMethodDeclarationCopy = new LinkedList();
    //permet de declarer la liste qui sert a contenir la copie des modifiers de la method recursive sans les modifiers
    LinkedList<String> FIFOforOriginalModifierOfMethodDeclarationCopy = new LinkedList();
    LinkedList<LinkedList<String>> FIFOofFIFOforOriginalModifierOfMethodDeclarationCopy = new LinkedList();
    //permet de declarer la liste qui sert a contenir la copie de la method recursive sans les modifiers
    LinkedList<String> FIFOforOriginalBlockOfMethodDeclarationCopy = new LinkedList();
    LinkedList<LinkedList<String>> FIFOofFIFOforOriginalBlockOfMethodDeclarationCopy = new LinkedList();
    //Sert à contenir la valeur  de : MaxDepth=<value>
    LinkedList<String> FIFOforValueofMaxDepth = new LinkedList();
    LinkedList<LinkedList<String>> FIFOofFIFOforValueofMaxDepth = new LinkedList();
    //Sert à contenir l'expression conditionnelle de treshold
    LinkedList<String> FIFOforExpressionofTreshold = new LinkedList();
    LinkedList<LinkedList<String>> FIFOofFIFOforExpressionofTreshold = new LinkedList();
    //sert à contenir la valeur de nthreads=<value>
    LinkedList<String> FIFOforValueofNthreads = new LinkedList();
    LinkedList<LinkedList<String>> FIFOofFIFOforValueofNthreads = new LinkedList();
    // it contains  symbols like formal parameters
    SymbolTable tableParInv = new SymbolTable();
    // it contains  symbols like formal parameters
    LinkedList<SymbolTable> FIFOoftableParInv = new LinkedList();
    //sert a contenir les arguments de la methode recursive
    LinkedList<String> myStatckForArgumentOfMethodSerial = new LinkedList();
    //sert à contenir les types des parametres de la methode recursive qui seront utilisés pour déclarer les champs dans la nouvelle classe
    LinkedList<String> myStatckForFieldDeclarationType = new LinkedList();
    //sert à contenir les noms des parametres de la methode recursive qui seront utilisés pour déclarer les champs dans la nouvelle classe
    LinkedList<String> myStatckForFieldDeclarationName = new LinkedList();
    //sert à contenir les methodes invoquées
    LinkedList<String> FIFOforMethodInvocation = new LinkedList();
    //sert à contenir les arguments des  methodes invoquées
    LinkedList<String> FIFOforMethodInvocationArguments = new LinkedList();
    //sert à contenir les résultats des  methodes invoquées
    LinkedList<String> FIFOforMethodInvocationResult = new LinkedList();
    //sert à contenir les variables contenant les valeurs retournées par la methode
    LinkedList<String> FIFOforResultOfTask = new LinkedList();
    //sert à contenir les déclarations des tasks
    LinkedList<String> FIFOforTaskDeclaration = new LinkedList();
    LinkedList<LinkedList<String>> FIFOofFIFOforTaskDeclaration = new LinkedList();
    //sert à contenir la valeur de l'index des tasks lors de la déclaration des tasks
    int indexOfTask = 1;
    //sert à contenir la valeur de l'index des tasks lors de l'initialisation des tasks
    int indexOfTask_ = 1;
    //sert à limiter le nombre de fois ou l'on écrit l'importation des packages de ForkJoin
    int counter = 0;

    public AddAcceptVisitor(PrintStream o) {
        super(o);
    }

    public Object visit(ASTFJCompAnnotation node, Object data) {
        //Recherche du noeud de la  declaration de méthode
        SimpleNode astmethoddeclaration = (SimpleNode) node.jjtGetParent();
        //Permet de recueillir le nom de la méthode
        String methodDeclarationName = "";
        //Au premier parcours du programme, ne pas ecrire sur Fichier
        if ((data.toString().compareTo("false")) == 0) {
            //Compte le nombre de  : [MethodName]task[indexOfTask]=null
            // Nous initialisons le compteur à chaque "//taskq"
            indexOfTask = 1;   
            LinkedList<String> FIFOforOriginalHeadOfMethodDeclarationCopy = new LinkedList();
           

            ////Etape1. Ecriture en Mémoire: mettre sur  liste les importations de librairies venant de ForkJoin
            if (counter == 0) {
                //If no version is choosen, the 7 version is choosen
                FJComp_Imporation_List.add("import java.util.concurrent.ForkJoinPool;");
                FJComp_Imporation_List.add("import java.util.concurrent.RecursiveAction;");

            }
            counter++;
            ////Etape 2. Ecriture en Mémoire: Copier la method Originale sur une liste
            //*****Début de Copie de la méthode Originale *****************//
           //Détermination du noeud de déclarartion de méthode
            while (astmethoddeclaration.id != JavaParserTreeConstants.JJTMETHODDECLARATION) {
                astmethoddeclaration = (SimpleNode) astmethoddeclaration.jjtGetParent();
            }
            //Détermination du noeud correspondant au corps de la classe
            SimpleNode astclassorinterfacebodydeclaration = (SimpleNode) node.jjtGetParent();
            while (astclassorinterfacebodydeclaration.id != JavaParserTreeConstants.JJTCLASSORINTERFACEBODYDECLARATION) {
                astclassorinterfacebodydeclaration = (SimpleNode) astclassorinterfacebodydeclaration.jjtGetParent();
            }
            //Repérer la méthode récursive à parallelizer parmi un ensemble de méthodes de la classe puis copier la méthode
            for (int i = 0; i < astclassorinterfacebodydeclaration.jjtGetNumChildren(); i++) {
                if (astmethoddeclaration == astclassorinterfacebodydeclaration.jjtGetChild(i)) {
                    try {
                        LinkedList<String> FIFOforOriginalModifierOfMethodDeclarationCopy = new LinkedList();
                        try {
                            super.myprintOriginalNodeCopy((SimpleNode) astclassorinterfacebodydeclaration.jjtGetChild(i - 1), FIFOforOriginalModifierOfMethodDeclarationCopy);
                            //Ecriture sur Mémoire: Copier le Modifier de la méthode récursive sur une liste
                            FIFOofFIFOforOriginalModifierOfMethodDeclarationCopy.add(FIFOforOriginalModifierOfMethodDeclarationCopy);
                            } catch (Exception e) {
                        }
                        for (int j = 0; j < astmethoddeclaration.jjtGetNumChildren(); j++) {
                            if (((SimpleNode) astmethoddeclaration.jjtGetChild(j)).id == JavaParserTreeConstants.JJTBLOCK) {
                                LinkedList<String> FIFOforOriginalBlockOfMethodDeclarationCopy = new LinkedList();
                                super.myprintOriginalNodeCopy((SimpleNode) astmethoddeclaration.jjtGetChild(j), FIFOforOriginalBlockOfMethodDeclarationCopy);
                                //Ecriture sur Mémoire: Copier le block de la méthode récursive sur une liste
                                FIFOofFIFOforOriginalBlockOfMethodDeclarationCopy.add(FIFOforOriginalBlockOfMethodDeclarationCopy);
                                break;
                            }                            
                            super.myprintOriginalNodeCopy((SimpleNode) astmethoddeclaration.jjtGetChild(j), FIFOforOriginalHeadOfMethodDeclarationCopy);
                        }
                        //Ecriture sur Mémoire: Copier l'entête de la méthode récursive sur une liste
                        FIFOofFIFOforOriginalHeadOfMethodDeclarationCopy.add(FIFOforOriginalHeadOfMethodDeclarationCopy);
                    } catch (Exception e) {
                        System.out.println("Erreur:" + e.getMessage());
                    }
                }
            }
           //*****Fin de Copie de la méthode Originale **********************************//
            ////Etape 3. Récupérer les valeurs des options
            //****Début récupération de la valeur de nthreads=<value>*****//
            LinkedList<String> FIFOforValueofNthreads = new LinkedList();
            super.myprintNumThread((SimpleNode) node, FIFOforValueofNthreads);
            //Ecriture sur Memoire: Ecrire la valeur de nthreads sur une liste
            FIFOofFIFOforValueofNthreads.add(FIFOforValueofNthreads);
            //****Fin récupération de la valeur de nthreads=<value>****//
            //****Début récupération de la valeur de MaxDepth=<value>***//
            LinkedList<String> FIFOforValueofMaxDepth = new LinkedList();
            super.myprintMaxDepth((SimpleNode) node, FIFOforValueofMaxDepth);
            //Ecriture sur Memoire: Ecrire la valeur de MaxDepth sur une liste
            FIFOofFIFOforValueofMaxDepth.add(FIFOforValueofMaxDepth);
            //****Fin récupération de la valeur de MaxDepth=<value>****//
            //****Début récupération de l'expression conditionnelle de treshold***//
            SimpleNode tresholdNode = (SimpleNode) node.jjtGetChild(0);
            if (((SimpleNode) tresholdNode).id == JavaParserTreeConstants.JJTFJCOMPOPTIONLIST) {
                for (int i = 0; i < tresholdNode.jjtGetNumChildren(); i++) {
                    if (((SimpleNode) tresholdNode.jjtGetChild(i).jjtGetChild(0)).id == JavaParserTreeConstants.JJTTRESHOLD) {
                        tresholdNode = (SimpleNode) tresholdNode.jjtGetChild(i).jjtGetChild(0);
                        LinkedList<String> FIFOforExpressionofTreshold = new LinkedList();
                        super.myprintTreshold((SimpleNode) tresholdNode, FIFOforExpressionofTreshold);
                        //Ecriture sur Memoire: Ecrire l'expression de Threshold sur une liste
                        FIFOofFIFOforExpressionofTreshold.add(FIFOforExpressionofTreshold);
                        break;
                    }
                }
            }
             //****Fin derécupération de l'expression conditionnelle de treshold***//
           ////Fin Etape 3.
           ////Etape 4. Détermination du nom de la méthode
            //Début détermination du  nom de la methode
            for (int i = 0; i < astmethoddeclaration.jjtGetNumChildren(); i++) {
                if (((SimpleNode) astmethoddeclaration.jjtGetChild(i)).id == JavaParserTreeConstants.JJTMETHODDECLARATOR) {
                    methodDeclarationName = ((SimpleNode) astmethoddeclaration.jjtGetChild(i)).jjtGetFirstToken().image;
                    break;
                }
            }
            //Fin détermination du  nom de la methode
            ////Fin Etape 4
            //Ecriture sur Mémoire: Ecrire la la liste de déclarion des tasks sur une liste
            FIFOofFIFOforTaskDeclaration.add(FIFOforTaskDeclaration);
            //Visite du contenu du noeud courant (FJCompAnnotation)
            print(node, data);
        }

        //Au Deuxième parcours du programme, écrire sur Fichier
        if ((data.toString().compareTo("true")) == 0) {
            //Etape 5
            //Ecriture sur Fichier: Afficher les déclarations des tasks
              /* fibonacciImpl task1 = null ;
                 fibonacciImpl task2 = null ;*/
            while (!FIFOforTaskDeclaration.isEmpty()) {
                out.print("\n " + FIFOforTaskDeclaration.pop());
            }
            //Index du dernier noeud qui est FJCompBlock
            int i = node.jjtGetNumChildren() - 1;
            //Ecriture sur Fichier:Visiter FJCompBlock et Afficher
              /* task1 = new fibonacciImpl ( n - 1 )
                 task2 = new fibonacciImpl ( n - 2 ) ; */
            for (int j = 0; j < ((SimpleNode) node.jjtGetChild(i)).jjtGetNumChildren(); j++) {
                print((SimpleNode) node.jjtGetChild(i).jjtGetChild(j), data);
            }
            //Ecriture sur Fichier: Afficher:
            /* invokeAll(task1,task2); */
            out.print("\n invokeAll(task1");
            for (int j = 2; j <= FIFOforResultOfTask.size(); j++) {
                out.print(",task" + j);
            }
            out.print(");");
            //Ecrire sur Fichier: Afficher:
            /*  x = task1 . result ;
                y = task2 . result ; */
            while (!FIFOforResultOfTask.isEmpty()) {
                out.print("\n " + FIFOforResultOfTask.pop());
            }
        }
        return data;
    }

    public Object visit(ASTModifiers node, Object data) {
        Token t = node.jjtGetFirstToken();
        //Au Deuxième parcours du programme, écrire sur Fichier
        if ((data.toString().compareTo("true")) == 0) {
            try {
                while (t.kind == JavaParserConstants.PUBLIC || t.kind == JavaParserConstants.STATIC || 
                        t.kind == JavaParserConstants.PROTECTED || t.kind == JavaParserConstants.PRIVATE ||
                        t.kind == JavaParserConstants.FINAL || t.kind == JavaParserConstants.ABSTRACT ||
                        t.kind == JavaParserConstants.SYNCHRONIZED || t.kind == JavaParserConstants.NATIVE ||
                        t.kind == JavaParserConstants.TRANSIENT || t.kind == JavaParserConstants.VOLATILE ||
                        t.kind == JavaParserConstants.STRICTFP) {
                    print(t);
                    t = t.next;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return data;
    }

    public Object visit(ASTImportDeclaration node, Object data) {
        //Le noeud d'importation existe
        isImportationDeclarationPresent = true;
        //Ecriture sur Fichier: Afficher le contenu du noeud d'importation
        print(node, data);
        //Au Deuxième parcours du programme, écrire sur Fichier
        if ((data.toString().compareTo("true")) == 0) {
            while (!FJComp_Imporation_List.isEmpty()) {
                out.println("");
                //Ecriture sur Fichier: Afficher l'importation des librairies issues de ForkJoin Framework
                /*  import java . util . concurrent . ForkJoinPool ;
                    import java . util . concurrent . RecursiveAction ;  */
                out.print(FJComp_Imporation_List.pop());
            }
        }
        return data;
    }

    public Object visit(ASTPackageDeclaration node, Object data) {
        //Le noeud de package existe
        isPackageDeclarationPresent = true;
        //Ecriture sur Fichier: Afficher le contenu du noeud de package
        print(node, data);
        //Au Deuxième parcours du programme, écrire sur Fichier
        if ((data.toString().compareTo("true")) == 0) {
            //Si dans le fichier original, import n'est pas déclaré, alors
            //ajouter les declarations de import generes par FJCOMP apres la declaration de package           
            if (!isImportationDeclarationPresent) {
                while (!FJComp_Imporation_List.isEmpty()) {
                     /* import java.util.concurrent.ForkJoinPool;
                        import java.util.concurrent.RecursiveAction; */
                    out.print("\n" + FJComp_Imporation_List.pop());
                }
            }
        }
        return data;
    }

    public Object visit(ASTTypeDeclaration node, Object data) {
        //Au Deuxième parcours du programme, écrire sur Fichier
        if ((data.toString().compareTo("true")) == 0) {
            //Si dans le fichier original, import et package ne sont  pas déclarés, alors
            //ajouter les declarations de import generes par FJCOMP juste avant la declaration de la classe
            if (!isImportationDeclarationPresent && !isPackageDeclarationPresent) {
                while (!FJComp_Imporation_List.isEmpty()) {
                    /* import java.util.concurrent.ForkJoinPool;
                        import java.util.concurrent.RecursiveAction; */
                    out.print("\n" + FJComp_Imporation_List.pop());
                }
            }

        }
        //Ecriture sur Fichier: Afficher la déclaration de la classe
        print(node, data);
        return data;
    }

    public Object visit(ASTMethodDeclaration node, Object data) {        
        //D'abord nous affichons le contenu de la méthode courante       
        Token mytoken = node.jjtGetFirstToken();
        //Pour vérifier la présence de //taskq à l'intérieur de la méthode
        boolean isAnnotationPresent = false;
        while (mytoken != node.jjtGetLastToken()) {
            if (mytoken.image.compareTo("//taskq") == 0) {
                isAnnotationPresent = true;
                break;
            }
            mytoken = mytoken.next;
        }
        //Si //taskq est présent à l'intérieur de la méthode, alors effectuer des modifications sur la méthode
        if (isAnnotationPresent) {
            //Au premier parcours du programme, ne pas ecrire sur Fichier
            if ((data.toString().compareTo("false")) == 0) {
                FIFOforTaskDeclaration = new LinkedList();
                tableParInv = new SymbolTable();
                data = print(node, data);
            }
       //Tout Ce qui suit vient juste apres le contenu de la methode courante
             //Au Deuxième parcours du programme, écrire sur Fichier
            if ((data.toString().compareTo("true")) == 0) {
                //Initialiser la liste servant à contenir la copie  du Modifier de la méthode récursive courante
                FIFOforOriginalModifierOfMethodDeclarationCopy = new LinkedList();
                //Initialiser la liste servant à contenir la copie de l'entête de la méthode récursive courante
                FIFOforOriginalHeadOfMethodDeclarationCopy = new LinkedList();
                //Intialiser la liste servant à contenir les arguments de la methode recursive
                myStatckForArgumentOfMethodSerial = new LinkedList();
                //Initialiser la liste servant à contenir les types des parametres de la methode recursive qui seront utilisés pour déclarer les champs dans la nouvelle classe
                myStatckForFieldDeclarationType = new LinkedList();
                //Initialiser la liste servant à contenir les noms des paramètres de la methode recursive qui seront utilisés pour déclarer les champs dans la nouvelle classe
                myStatckForFieldDeclarationName = new LinkedList();
                //Liste servant à contenir les methodes invoquées
                FIFOforMethodInvocation = new LinkedList();
                //Liste servant à contenir les arguments des  methodes invoquées
                FIFOforMethodInvocationArguments = new LinkedList();
                //Liste servant à contenir les résultats des  methodes invoquées
                FIFOforMethodInvocationResult = new LinkedList();
                //Liste servant à contenir les variables contenant les valeurs retournées par les methodes invoquées
                FIFOforResultOfTask = new LinkedList();
                //Liste servant à contenir les déclarations des tasks
                FIFOforTaskDeclaration = new LinkedList();
                //Variable servant à contenir la valeur de l'index des tasks lors de la déclaration des tasks
                indexOfTask = 1;
                //Variable servant à contenir la valeur de l'index des tasks lors de l'initialisation des tasks
                indexOfTask_ = 1;
                try {
                    //Ecriture sur Mémoire: Declaration tasks
                    FIFOforTaskDeclaration = FIFOofFIFOforTaskDeclaration.pop();
                } catch (Exception e) {
                }
                try {
                    //Ecriture sur Mémoire: Contenu de la table des symboles
                    tableParInv = FIFOoftableParInv.pop();
                } catch (Exception e) {
                }
                try {
                    //Ecriture sur Mémoire: Copie du Modifier de la méthode récursive originale
                    FIFOforOriginalModifierOfMethodDeclarationCopy = FIFOofFIFOforOriginalModifierOfMethodDeclarationCopy.pop();
                } catch (Exception e) {
                }
                try {
                    //Ecriture sur Mémoire: Copie du Block de la méthode récursive originale
                    FIFOforOriginalBlockOfMethodDeclarationCopy = FIFOofFIFOforOriginalBlockOfMethodDeclarationCopy.pop();
                } catch (Exception e) {
                }
                try {
                    //Ecriture sur Mémoire: Copie de l'entête de la méthode récursive originale
                    FIFOforOriginalHeadOfMethodDeclarationCopy = FIFOofFIFOforOriginalHeadOfMethodDeclarationCopy.pop();
                } catch (Exception e) {
                }
                try {
                    //Ecriture sur Mémoire: Valeur de MaxDepth
                    FIFOforValueofMaxDepth = FIFOofFIFOforValueofMaxDepth.pop();
                } catch (Exception e) {
                }
                try {
                    //Ecriture sur Mémoire: Expression de Threshold
                    FIFOforExpressionofTreshold = FIFOofFIFOforExpressionofTreshold.pop();
                } catch (Exception e) {
                }
                try {
                    ////Ecriture sur Mémoire: Valeur de nThreads
                    FIFOforValueofNthreads = FIFOofFIFOforValueofNthreads.pop();
                } catch (Exception e) {
                }                
                //Début délimitation du champ d'intervention pour que la table des symboles recueille les symboles
                tableParInv.addScope();
                //Début détermination du  nom de la methode
                String methodDeclarationName = "";
                for (int i = 0; i < node.jjtGetNumChildren(); i++) {
                    if (((SimpleNode) node.jjtGetChild(i)).id == JavaParserTreeConstants.JJTMETHODDECLARATOR) {
                        methodDeclarationName = ((SimpleNode) node.jjtGetChild(i)).jjtGetFirstToken().image;
                        break;
                    }
                }
                //Fin détermination du  nom de la methode
                //Début Détermination du type retourné par la methode
                String resultTypeName = "";
                for (int i = 0; i < node.jjtGetNumChildren(); i++) {
                    if (((SimpleNode) node.jjtGetChild(i)).id == JavaParserTreeConstants.JJTRESULTTYPE) {
                        try {
                            Token t = ((ASTResultType) node.jjtGetChild(i)).jjtGetFirstToken();
                            while (t != ((ASTResultType) node.jjtGetChild(i)).jjtGetLastToken()) {
                                resultTypeName = resultTypeName + " " + t.image;
                                t = t.next;
                            }
                            resultTypeName = resultTypeName + " " + t.image;
                            break;
                        } catch (Exception e) {
                            break;
                        }
                    }
                }
                //Fin Détermination du type retourné par la methode
                //L'index correspondant au dernier noeud               
                int lastIndex = node.jjtGetNumChildren() - 1;
                
               //**Début d'écriture sur le fichier du code suivant: Code1
                //Début écrirure  Code 1:
                /* int numthreads = 4 ;
                   ForkJoinPool pool = new ForkJoinPool ( numthreads ) ;
                   fibonacciImpl afibonacciImpl = new fibonacciImpl ( n ) ;
                   fibonacciImpl afibonacciImpl = new fibonacciImpl (0,  n ) ; //Si MxDepth est spécifié
                   pool . invoke ( afibonacciImpl ) ;
                   return afibonacciImpl . result ; */
                out.print("\n");
                /* A supprimer
                for (int i = 0; i < FIFOforOriginalModifierOfMethodDeclarationCopy.size(); i++) {
                    String elt_FIFOforOriginalModifierOfMethodDeclarationCopy = FIFOforOriginalModifierOfMethodDeclarationCopy.get(i);

                }*/
                //Ecrire sur Ficher: Début
                /* public long fibonacci ( int n ) { */
                for (int i = 0; i < FIFOforOriginalHeadOfMethodDeclarationCopy.size(); i++) {
                    String elt_FIFOforOriginalHeadOfMethodDeclarationCopy = FIFOforOriginalHeadOfMethodDeclarationCopy.get(i);
                    out.print(elt_FIFOforOriginalHeadOfMethodDeclarationCopy);
                }
                out.print("\n {");
                //Ecrire sur Ficher: Fin
                //Ecriture sur Fichier:
                /*int numthreads = 4;*/
                out.println("String nbthreadsStr=System.getProperty(\"fjcomp.threads\") ;");
                out.print("\n int numthreads=");
                try {
                    //Ecrire la valeur specifie par l'utilisateur
                    out.print(FIFOforValueofNthreads.pop() + ";");
                } catch (Exception e) {
                    //Si la clause nthreads n'est pas préciser alors Ecrir sur Fichiere:
                    /*  Runtime.getRuntime().availableProcessors(); */
                    out.print("Runtime.getRuntime().availableProcessors();");
                }
                //Recupérer la valeur de la variable d'environnement
                out.println("try{");
                out.println("numthreads = Integer.parseInt(nbthreadsStr);");
                out.println("if(numthreads==0){System . out . println ( \"La valeur de fjcomp.threads doit etre differente de zero\" ) ;");
                out.println("System . exit ( 1 ) ; }");
                out.println("}catch(Exception ex){");
                out.println("if (nbthreadsStr==null);");
                out.println("else {System.out.println(\"La valeur fr fjcomp.threads doit etre un entier\");");
                out.println(" System.exit(1);}");
                out.println("}");
                //Ecriture sur Fichier: Fin
                // Ecriture sur Fichier : Début
                //ForkJoinPool pool = new ForkJoinPool ( numthreads ) ;
                out.print("\n ForkJoinPool pool=new ForkJoinPool (numthreads);");
                //Ecriture sur Fichier: Fin
                //Ecriture sur Fichier: Début
                /*fibonacciImpl afibonacciImpl = new fibonacciImpl ( n ) ;
                 fibonacciImpl afibonacciImpl = new fibonacciImpl (0, n ); //Si MaxDepth est spécifié*/
                out.print("\n" + methodDeclarationName + "Impl " + "a" + methodDeclarationName + "Impl");
                out.print("=new " + methodDeclarationName + "Impl (");
                //Nous affichons les arguments de la méthode courante
                //**Début Détermination  des arguments
                //Initialisation de la table des symboles
                tableParInv.getInit();           
                SymbolTable.Symbol symbol;
                //Nous empilons les ymboles dont nous avons besoin dans différentes piles
                try {
                    do {
                        //Chercher le symbole suivant dans la table des symboles
                        symbol = tableParInv.getNext();
                        //Empiler les noms des arguments de la méthode récursive originale
                        myStatckForArgumentOfMethodSerial.push(symbol.name);
                        //Empiler les types des arguments de la méthode récursive originale
                        myStatckForFieldDeclarationType.push(symbol.sig);
                        //Empiler les noms des arguments de la méthode récursive originale
                        myStatckForFieldDeclarationName.push(symbol.name);
                    } while (true);
                } catch (Exception e) {
                }
                //Au cas ou MaxDepth=<value> est spécifiié par l'utilisateur:                
                try {
                    //Si la méthode récursive originale n'a aucun paramètre alors
                    if (myStatckForArgumentOfMethodSerial.isEmpty()) {                        
                        //Si MaxDepth est spécifié
                        if (!FIFOforValueofMaxDepth.isEmpty()||(FIFOforExpressionofTreshold.isEmpty() && FIFOforValueofMaxDepth.isEmpty())) {
                            //Ecriture sur fichier de: 0
                            out.print("0");
                        }
                    }
                    //Si la méthode récursive originale a au moins 1 paramètre alors
                    else {
                        //Si MaxDepth est spécifié
                        if (!FIFOforValueofMaxDepth.isEmpty()||(FIFOforExpressionofTreshold.isEmpty() && FIFOforValueofMaxDepth.isEmpty())) {
                            //Ecriture sur fichier de: 0,
                            out.print("0,");
                        }
                    }
                } catch (Exception e) {
                }
                //Ecriture sur Fichier des arguments de fibonacciImpl qui :  n
                try {
                    String elt_myFifoForArgumentOfMethod = myStatckForArgumentOfMethodSerial.pop();
                    out.print(elt_myFifoForArgumentOfMethod);
                    do {
                        elt_myFifoForArgumentOfMethod = myStatckForArgumentOfMethodSerial.pop();
                        out.print("," + elt_myFifoForArgumentOfMethod);
                    } while (true);
                } catch (Exception e) {
                }
                //**Fin Détermination  Determination of the arguments
                out.print(");");
              //Fin Ecriture sur Fichier de:  fibonacciImpl afibonacciImpl = new fibonacciImpl ( n ) ;
                // Début écriture : pool . invoke ( afibonacciImpl ) ;
                out.print("\n pool.invoke(" + "a" + methodDeclarationName + "Impl);");
                // Fin écriture sur Fichier : pool . invoke ( afibonacciImpl ) ;
                // Si la methode retourne alors
                //Début écriture sur Fichier : return afibonacciImpl . result ;               
                if (resultTypeName.trim().compareTo("void") != 0) {
                    out.print("\n return a" + methodDeclarationName + "Impl.result;");
                }
                //Fin écriture : return afibonacciImpl . result ;
                out.print("\n }");
                //Fin Ecriture sur Fichier  du Code 1

                //Début Ecriture: Code 2
                /* Code 2:
                 private  fibonacciImpl extends RecursiveAction {
                 ...
                 }
                 */
                //Vérifier si la méthode est static ou non
                boolean isStaticModifier = false;
                for (int i = 0; i < FIFOforOriginalModifierOfMethodDeclarationCopy.size(); i++) {
                    String elt_FIFOforOriginalModifierOfMethodDeclarationCopy = FIFOforOriginalModifierOfMethodDeclarationCopy.get(i);
                    if (elt_FIFOforOriginalModifierOfMethodDeclarationCopy.compareTo("static") == 0) {
                        isStaticModifier = true;
                    }
                }
                //Ecrire sur Fichier: private
                out.print("\n private");
                //Si la méthode est static
                if (isStaticModifier) {
                    //Ecrire sur Fichier: static
                    out.print(" static");
                }
                //Ecrire sur Fichier:  
                /* private class fibonacciImpl extends RecursiveAction { */
                out.print(" class " + methodDeclarationName + "Impl extends RecursiveAction {");
               

                // Début Ecriture de: declaration du champ maxdepth si la clause maxdepth est spécifiée
                if (!FIFOforValueofMaxDepth.isEmpty()) {
                    //Ecrire sur Fichier: 
                    /*private int maxdepth;*/
                    out.print("\n private int maxdepth;");                  
                }
                 else if (!FIFOforExpressionofTreshold.isEmpty()) {
                 }else{
                     out.print("\n private int maxdepth;"); 
                 }

                 //out.print("\nif(maxdepthStr!=null) MAX_DEPTH=Integer.parseInt(maxdepthStr);");
                // Fin Ecriture de: declaration du champ maxdepth si la clause maxdepth est spécifiées
                //Ecriture sur Fichier  : déclarations des champs qui ne sont rien d'autre que les arguments de la méthode
                /* private int n ; */
                for (int i = 0; i < myStatckForFieldDeclarationType.size(); i++) {
                    out.print("\n private " + myStatckForFieldDeclarationType.get(i) + " " + myStatckForFieldDeclarationName.get(i) + ";");
                }
                //Début Ecriture de : declaration du champ result si la methode retourne
                if (resultTypeName.trim().compareTo("void") != 0) {
                    /*private long result ;*/
                    out.print("\n private " + resultTypeName + " result;");
                }
                //Fin Ecriture de : declaration du champ result si la methode retourne
                //Début écriture: déclaration du constructeur: 
                /*  private fibonacciImpl ( int n ) {
                       this . n = n ;
                     } */
                //Début écriture: déclaration de l'entete du constructeur
                /* private fibonacciImpl ( */
                out.print("\n private " + methodDeclarationName + "Impl(");
                //Debut Ecriture des parametres du constructeur
                //Debut Si MaxDepth est spécifié
                if (!FIFOforValueofMaxDepth.isEmpty() ||(FIFOforExpressionofTreshold.isEmpty() && FIFOforValueofMaxDepth.isEmpty())) {
                    try {
                        //Si la méthode récursive originale n'a acun argument
                        if (myStatckForFieldDeclarationType.isEmpty()) {
                            //Ecrire sur Fichier: int maxdepth
                            out.print(" int maxdepth");
                        }
                        //Si la méthode récursive originale a au moins un argument
                        else {
                            //Ecrire sur Fichier: int maxdepth,
                            out.print(" int maxdepth,");
                        }

                    } catch (Exception e) {
                    }
                }
                //Fin Si MaxDepth est spécifié
                //Début écriture sur Fichier des paramètres du constructeur
                try {
                    out.print(myStatckForFieldDeclarationType.get(0) + " " + myStatckForFieldDeclarationName.get(0));
                    for (int i = 1; i < myStatckForFieldDeclarationType.size(); i++) {
                        out.print("," + myStatckForFieldDeclarationType.get(i) + " " + myStatckForFieldDeclarationName.get(i));
                    }
                } catch (Exception e) {
                }
                //Fin écriture sur Fichier des paramètres du constructeur
                out.print("){");
                //Fin écriture: déclaration de l'entete du constructeur
                //Début écriture: contenu de déclaration du constructeur
                //Si MaxDepth est spécifié
                if (!FIFOforValueofMaxDepth.isEmpty()||(FIFOforExpressionofTreshold.isEmpty() && FIFOforValueofMaxDepth.isEmpty())) {
                    //Ecrire sur Fichier: this.maxdepth=maxdepth;
                    out.print("\n this.maxdepth=maxdepth;");
                }
                //Ecriture sur Fichier:
                /* this . n = n ;  */
                try {                    
                    for (int i = 0; i < myStatckForFieldDeclarationType.size(); i++) {
                        out.print("\n this." + myStatckForFieldDeclarationName.get(i) + "=" + myStatckForFieldDeclarationName.get(i) + ";");
                    }
                } catch (Exception e) {
                }
                out.print("\n }");
                //Fin Déclaration du constructeur

                //Début la déclaration du block de la méthode de méthode
                //Début Parcourir toute la méthode, puis remplacer return par result=
                Token t_ = node.jjtGetFirstToken();
                if (resultTypeName.compareTo("void") != 0) {
                    while (t_ != node.jjtGetLastToken()) {
                        if (t_.image.compareTo("return") == 0) {
                            t_.image = "result=";
                        }
                        t_ = t_.next;
                    }
                }
                //Fin Parcourir toute la méthode, puis remplacer return par result=
                //Ecriture sur Fichier:
                /* protected void compute(){...}*/
                out.print("\n protected void compute(){");
                out.print("\n int MAX_DEPTH;");
                out.println("String maxdepthStr=System.getProperty(\"fjcomp.maxdepth\") ;");
                if (!FIFOforValueofMaxDepth.isEmpty()) {                    
                     out.print("\nMAX_DEPTH="+FIFOforValueofMaxDepth.getFirst()+";") ;
                }
                out.print("\ntry{");
                out.print("\nMAX_DEPTH = Integer.parseInt(maxdepthStr);");
                out.print("\nif(MAX_DEPTH==0){System . out . println ( \"La valeur de fjcomp.maxdepth doit etre differente de zero\" ) ;");
                out.print("\nSystem . exit ( 1 ) ; }");
                out.print("\n}catch(Exception ex){");
                out.print("\nif (maxdepthStr==null);");// NUM_"+X+" = Runtime.getRuntime().availableProcessors();");
                out.print("\nelse {System.out.println(\"La valeur  fjcomp.maxdepth doit etre un entier\");");
                out.print("\n System.exit(1);}");
                out.print("\n}");

               // out.print("\n String  THRESHOLD_;");
                //out.println("String thresholdStr=System.getProperty(\"fjcomp.threshold\") ;");

                /*if (!FIFOforExpressionofTreshold.isEmpty()) {
                    out.print("TRESHOLD_="+FIFOforExpressionofTreshold.pop());
                }*/
                //out.print("if(thresholdStr!=null) TRESHOLD_=thresholdStr");

                //Si MaxDepth est spécifié
                if (!FIFOforValueofMaxDepth.isEmpty()) {
                    //Ecrire sur Fichier: if(maxdepth>=4)){
                    //out.print("\n if (maxdepth>=" + FIFOforValueofMaxDepth.getFirst() + "){");
                    out.print("\n if (maxdepth>=MAX_DEPTH){");
                } 
                //Si Treshold est spécifié
                else if (!FIFOforExpressionofTreshold.isEmpty()) {
                    out.print("\n");
                    /*
                    while (!FIFOforExpressionofTreshold.isEmpty()) {
                        //Ecrire sur Fichier: if ( n < 10 )                        
                        out.print(FIFOforExpressionofTreshold.pop());
                        //out.print("TRESHOLD_="+FIFOforExpressionofTreshold.pop());
                    }*/
                    for(int i=0;i<FIFOforExpressionofTreshold.size();i++)
                            out.print(FIFOforExpressionofTreshold.get(i));
                    out.print("{");
                }
                //Si ni MaxDepth, ni Threshold ne sont spécifiés
                else {
                    //Ecrire sur Fichier: if (maxdepth>=1){
                    out.print("\n if (maxdepth>=1){");
                }
                //Debut Ecrire sur Fichier : invoquer fonction séquentielle:
                /*   result=fibonacci(n);  */
                // Si la méthode retourne
                if (resultTypeName.trim().compareTo("void") != 0) {
                    //Ecrire sur Fichier: result=
                    out.print("\n result= ");
                } else {
                    out.print("\n");
                }
                //Ecrire sur Fichier: fibonacci(
                out.print(methodDeclarationName + "(");
                //Nous affichons les arguments de la méthode courante
                //**Début Détermination  Determination of the arguments
                Stack<String> myStatckForArgumentOfMethodSerial_ = new Stack();
                //Initialisation de la table des symboles
                tableParInv.getInit();            
                SymbolTable.Symbol symbol_;
                //Nous empilons les symboles dont nous avons besoin dans différentes piles
                try {
                    do {
                        //Obtenir  et empiler le symbole suivant dans la table des symboles
                        symbol_ = tableParInv.getNext();   
                        myStatckForArgumentOfMethodSerial_.push(symbol_.name);
                    } while (true);
                } catch (Exception e) {
                }
                //Une fois que nous avons empilé les symboles, Ecrire sur Fichier
                try {
                    String elt_myFifoForArgumentOfMethod_ = myStatckForArgumentOfMethodSerial_.pop();
                    //Ecrire sur Fichier: n
                    out.print(elt_myFifoForArgumentOfMethod_);
                    do {
                        elt_myFifoForArgumentOfMethod_ = myStatckForArgumentOfMethodSerial_.pop();
                        out.print("," + elt_myFifoForArgumentOfMethod_);
                    } while (true);
                } catch (Exception e) {
                }
                out.print(");");
                //Fin Ecrire : invoquer fonction séquentielle:  result=fibonacci(n);
                //Ecrire sur Fichier: } else{
                out.print("\n } else{");
                //Visiter et Ecrire sur Fichier le contenu du bloc de la méthode récursive
                //Ce qui signifie que le noeud //task sera du même coup visité alors se référer à :
                //public Object visit(ASTFJCompTask node, Object data)
                for (int i = 0; i < node.jjtGetChild(lastIndex).jjtGetNumChildren(); i++) {
                    print((SimpleNode) node.jjtGetChild(lastIndex).jjtGetChild(i), data);
                }
                //Fin du bloc de else
                out.print("\n }");
                //Fin du block de la déclaration de méthode
                out.print("\n }");
                //Fin écriture de : protected void compute(){...}
              
                //Début Ecriture sur Fichier  de la méthode originale
                /*  private long fibonacci ( int n ) {  */                
                //Ecrire sur Fichier:  private
                out.print("\n private ");
                //Ecrire sur fichier l'entête de la copie de méthode récursive originale
                /* long fibonacci ( int n ) */
                for (int i = 0; i < FIFOforOriginalHeadOfMethodDeclarationCopy.size(); i++) {
                    String elt_FIFOforOriginalHeadOfMethodDeclarationCopy = FIFOforOriginalHeadOfMethodDeclarationCopy.get(i);
                    out.print(elt_FIFOforOriginalHeadOfMethodDeclarationCopy);
                }
                 //Ecrire sur fichier le bloc de la copie de méthode récursive originale
                for (int i = 0; i < FIFOforOriginalBlockOfMethodDeclarationCopy.size(); i++) {
                    String elt_FIFOforOriginalBlockOfMethodDeclarationCopy = FIFOforOriginalBlockOfMethodDeclarationCopy.get(i);
                    out.print(elt_FIFOforOriginalBlockOfMethodDeclarationCopy);
                }
                //Fin écriture de la méthode originale
                out.print("\n }");
                //Fin Ecriture:  private class fibonacciImpl extends RecursiveAction {...}
                tableParInv.killScope();
                //Fin délimitation du champ pour la détermination de la table des symboles
            }
        }
        //Si //taskq n'est pas présent à l'intérieur de la méthode, alors afficher simplement le contenu de la méthode
        else {
            //Ecrire sur disque le contenu de la méthode sans aucune modification
            print(node, data);
        }
        return data;
    }

    /*****Recherche des parametres de la méthode recursive et insérér dans la table des symboles***/
    /*******Nous remplissons la table des symboles******************************************************/
    public Object visit(ASTFormalParameter astformalparameter, Object obj) {
        //Node pour remonter jusqu'au noeud de la déclararion de la méthode récursive
        SimpleNode node_ = (SimpleNode) astformalparameter.jjtGetParent().jjtGetParent().jjtGetParent();
        Token mytoken = node_.jjtGetFirstToken();
        //Vérifier si la méthode contient l'annotation //taskq
        boolean isAnnotationPresent = false;
        while (mytoken != node_.jjtGetLastToken()) {
            if (mytoken.image.compareTo("//taskq") == 0) {
                isAnnotationPresent = true;
                break;
            }
            mytoken = mytoken.next;
        }
        //Si l'annotation taskq est présente
        if (isAnnotationPresent) {
            if ((obj.toString().compareTo("false")) == 0) {
                ASTType asttype = (ASTType) astformalparameter.jjtGetChild(1); //this node denotes the type of the formalparameter
                //Ce noeud correspond au nom du parametre
                ASTVariableDeclaratorId astvariabledeclaratorid = (ASTVariableDeclaratorId) astformalparameter.jjtGetChild(2);
                //mettre sur la variable s le nom du paramètre courant
                String s = ((SimpleNode) astformalparameter.jjtGetChild(2)).jjtGetFirstToken().toString(); 
                String s1 = "";
                Token token = asttype.jjtGetFirstToken();  
                do {
                    //mettre sur la variable s1 le type du parametre courant
                    s1 = s1 + " " + token.toString();
                    if (token == asttype.jjtGetLastToken()) {
                        break;
                    }
                    token = token.next;
                } while (true);
                for (Token token1 = astvariabledeclaratorid.jjtGetFirstToken(); token1 != astvariabledeclaratorid.jjtGetLastToken();) {
                    token1 = token1.next;
                    //mettre sur la variable s1 le type du parametre courant
                    s1 = s1 + " " + token1.toString();
                }
                //Ajouter le nom du paramètre dans la table des symboles
                SymbolTable.Symbol symbolParInv = tableParInv.addSymbol(s);
                //Ajouter le type du paramètre dans la table des symboles
                symbolParInv.sig = s1.trim();
                symbolParInv.isInitialized = false;
                //Mettre le tout sur une liste
                FIFOoftableParInv.add(tableParInv);
            }
        }
        //Visiter et afficher le contenu du noeud
        print(astformalparameter, obj);
        return obj;
    }

    public Object visit(ASTFJCompTask node, Object data) {
        //Neoud pour remonter juste qu'au noeud de déclaration de méthode
        SimpleNode astmethoddeclaration = (SimpleNode) node.jjtGetParent();
        String methodDeclarationName = "";
        //Détermination du noeud de déclaration de méthode
        while (astmethoddeclaration.id != JavaParserTreeConstants.JJTMETHODDECLARATION) {
            astmethoddeclaration = (SimpleNode) astmethoddeclaration.jjtGetParent();
        }
        //Détermination du nom de la méthode
        for (int i = 0; i < astmethoddeclaration.jjtGetNumChildren(); i++) {
            if (((SimpleNode) astmethoddeclaration.jjtGetChild(i)).id == JavaParserTreeConstants.JJTMETHODDECLARATOR) {
                methodDeclarationName = ((SimpleNode) astmethoddeclaration.jjtGetChild(i)).jjtGetFirstToken().image;
                break;
            }
        }
        //Au premier parcours du programme, ne pas ecrire sur Fichier
        if (data.toString().compareTo("false") == 0) {
            //Ecrire sur Mémoire: fibonacciImpl task1 = null ;
            FIFOforTaskDeclaration.add(methodDeclarationName + "Impl task" + indexOfTask + " =null ;");
            indexOfTask++;
        }
        //Au Deuxième parcours du programme, écrire sur Fichier
        if (data.toString().compareTo("true") == 0) {
            //Début écrire: sur Fichier: 
            /* task1 = new fibonacciImpl ( n - 1 ) ; */
            out.print("\n task" + indexOfTask_ + " =new " + methodDeclarationName + "Impl");
            out.print("(");
            //Determinations des arguments
            //Si MaxDepth est spécifié
            if (!FIFOforValueofMaxDepth.isEmpty()||(FIFOforExpressionofTreshold.isEmpty() && FIFOforValueofMaxDepth.isEmpty())) {
                //Ecrire sur Fichier: maxdepth+1,
                out.print("maxdepth+1,");
            }
            //Visiter et Afficher le noeud ArgumentList() de la méthode récursive invoquée
            print((SimpleNode) node.jjtGetChild(1).jjtGetChild(0), data);
            out.print(")");
            out.print(";");
            Token t = node.jjtGetFirstToken();
            //Si la méthode retourne
            if (t.next.next.image.compareTo("=") == 0) {
                //Ecrire sur Mémoire: x = task1 . result ;
                FIFOforResultOfTask.add(t.next.image + "= task" + indexOfTask_ + ".result;");
            } else {
                FIFOforResultOfTask.add("");
            }
            indexOfTask_++;
        }
        return data;
    }
}