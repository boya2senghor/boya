package FJCompCompiler;
import java.io.PrintStream;

public class DeleteDirective extends UnparseVisitor
{
  public DeleteDirective(PrintStream o)
  {
    super(o);
  }
  public Object visit(ASTFJCompBlock node, Object data)
  {      
      for(int i=0;i<node.jjtGetNumChildren();i++){
        print((SimpleNode)node.jjtGetChild(i),data);
      }      
      return data;
  }
    public Object visit(ASTModifiers node, Object data) {
        Token t = node.jjtGetFirstToken();   
        if ((data.toString().compareTo("true")) == 0) {
            try {
                while (t.kind == JavaParserConstants.PUBLIC || t.kind == JavaParserConstants.STATIC || t.kind == JavaParserConstants.PROTECTED || t.kind == JavaParserConstants.PRIVATE || t.kind == JavaParserConstants.FINAL || t.kind == JavaParserConstants.ABSTRACT || t.kind == JavaParserConstants.SYNCHRONIZED || t.kind == JavaParserConstants.NATIVE || t.kind == JavaParserConstants.TRANSIENT || t.kind == JavaParserConstants.VOLATILE || t.kind == JavaParserConstants.STRICTFP) {
                    print(t);                   
                    t = t.next;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return data;
    }
}
