/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fjcompTestAll;


public class StopWatch {
    long startTime;
    long stopTime;
    
    public StopWatch(){
        startTime = System.currentTimeMillis();

    }
    public void stop(){
        stopTime = System.currentTimeMillis();

    }

    public long getElapsedTime(){
        return stopTime - startTime;

    }    

}
