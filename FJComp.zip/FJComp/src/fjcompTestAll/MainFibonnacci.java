package fjcompTestAll;

public class MainFibonnacci {

    public static void main(String args[]) {
        int n = Integer.parseInt(args[0]);
        StopWatch stopWatch = new StopWatch();
        Fibonacci Fib = new Fibonacci();
        long result1 = Fib.fibonacci(n);
        stopWatch.stop();
        System.out.println("Fibonacci Computed Result: " + result1);
        System.out.println("Fibonacci Elapsed Time: " + stopWatch.getElapsedTime());
    }
}
