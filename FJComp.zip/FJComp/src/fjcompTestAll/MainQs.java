package fjcompTestAll;

public class MainQs {

    public static void main(String[] args) {
        int N = Integer.parseInt(args[0]);
        java.util.Random generator = new java.util.Random(1101979);
        int a[] = new int[N];
        for (int i = 0; i < N; i++) {
            a[i] = generator.nextInt(400000000);
        }
        StopWatch stopWatch = new StopWatch();
        QS bigProblem = new QS(a, 0, a.length - 1);
        bigProblem.sequentialQuicksort(a, 0, a.length - 1);
        stopWatch.stop();
        testQS(a);
        //for(int i=0;i<a.length;i++) System.out.println(a[i]);
        System.out.println("Sequential QS Elapsed Time: " + stopWatch.getElapsedTime());
    }

    public static void testQS(int numbers[]) {
        for (int i = 0; i < numbers.length - 1; i++) {
            if (numbers[i] > numbers[i + 1]) {
                System.out.println("faild");
                System.exit(1);
            }
        }
        System.out.println("successfull");
    }
}
