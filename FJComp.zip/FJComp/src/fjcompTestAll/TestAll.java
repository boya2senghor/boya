/*************************************************************************
*   Ce code est généré et mis en forme par le compilateur FJComp         *
* Auteur du Compilateur: Abdourahmane Senghor  -- boya2senghor@yahoo.fr  *
**************************************************************************/


package fjcompTestAll ;
import java . util . concurrent . ForkJoinPool ;
import java . util . concurrent . RecursiveAction ;
public class TestAll {
   public class Fibonnacci {
      public long fibonacci ( int n ) {
         String nbthreadsStr = System . getProperty ( "fjcomp.threads" ) ;
         int numthreads = Runtime . getRuntime ( ) . availableProcessors ( ) ;
         try {
            numthreads = Integer . parseInt ( nbthreadsStr ) ;
            if ( numthreads == 0 ) {
               System . out . println ( "La valeur de fjcomp.threads doit etre differente de zero" ) ;
               System . exit ( 1 ) ;
            }
         }
         catch ( Exception ex ) {
            if ( nbthreadsStr == null ) ;
            else {
               System . out . println ( "La valeur fr fjcomp.threads doit etre un entier" ) ;
               System . exit ( 1 ) ;
            }
         }
         ForkJoinPool pool = new ForkJoinPool ( numthreads ) ;
         fibonacciImpl afibonacciImpl = new fibonacciImpl ( n ) ;
         pool . invoke ( afibonacciImpl ) ;
         return afibonacciImpl . result ;
      }
      private class fibonacciImpl extends RecursiveAction {
         private int n ;
         private long result ;
         private fibonacciImpl ( int n ) {
            this . n = n ;
         }
         protected void compute ( ) {
            int MAX_DEPTH ;
            String maxdepthStr = System . getProperty ( "fjcomp.maxdepth" ) ;
            try {
               MAX_DEPTH = Integer . parseInt ( maxdepthStr ) ;
               if ( MAX_DEPTH == 0 ) {
                  System . out . println ( "La valeur de fjcomp.maxdepth doit etre differente de zero" ) ;
                  System . exit ( 1 ) ;
               }
            }
            catch ( Exception ex ) {
               if ( maxdepthStr == null ) ;
               else {
                  System . out . println ( "La valeur  fjcomp.maxdepth doit etre un entier" ) ;
                  System . exit ( 1 ) ;
               }
            }
            if ( n < 10 ) {
               result = fibonacci ( n ) ;
            }
            else {
               if ( n == 0 ) result = 0 ;
               if ( n == 1 ) result = 1 ;
               long x , y ;
               fibonacciImpl task1 = null ;
               fibonacciImpl task2 = null ;
               task1 = new fibonacciImpl ( n - 1 ) ;
               task2 = new fibonacciImpl ( n - 2 ) ;
               invokeAll ( task1 , task2 ) ;
               x = task1 . result ;
               y = task2 . result ;
               result = x + y ;
            }
         }
         private long fibonacci ( int n ) {
            if ( n == 0 ) return 0 ;
            if ( n == 1 ) return 1 ;
            long x , y ;
            x = fibonacci ( n - 1 ) ;
            y = fibonacci ( n - 2 ) ;
            return x + y ;
         }
      }
   }
   public class QS {
      public int a [ ] , left , right ;
      public QS ( int [ ] a , int left , int right ) {
         this . a = a ;
         this . left = left ;
         this . right = right ;
      }
      public void sequentialQuicksort ( int [ ] a , int left , int right ) {
         String nbthreadsStr = System . getProperty ( "fjcomp.threads" ) ;
         int numthreads = Runtime . getRuntime ( ) . availableProcessors ( ) ;
         try {
            numthreads = Integer . parseInt ( nbthreadsStr ) ;
            if ( numthreads == 0 ) {
               System . out . println ( "La valeur de fjcomp.threads doit etre differente de zero" ) ;
               System . exit ( 1 ) ;
            }
         }
         catch ( Exception ex ) {
            if ( nbthreadsStr == null ) ;
            else {
               System . out . println ( "La valeur fr fjcomp.threads doit etre un entier" ) ;
               System . exit ( 1 ) ;
            }
         }
         ForkJoinPool pool = new ForkJoinPool ( numthreads ) ;
         sequentialQuicksortImpl asequentialQuicksortImpl = new sequentialQuicksortImpl ( 0 , a , left , right ) ;
         pool . invoke ( asequentialQuicksortImpl ) ;
      }
      private class sequentialQuicksortImpl extends RecursiveAction {
         private int maxdepth ;
         private int [ ] a ;
         private int left ;
         private int right ;
         private sequentialQuicksortImpl ( int maxdepth , int [ ] a , int left , int right ) {
            this . maxdepth = maxdepth ;
            this . a = a ;
            this . left = left ;
            this . right = right ;
         }
         protected void compute ( ) {
            int MAX_DEPTH ;
            String maxdepthStr = System . getProperty ( "fjcomp.maxdepth" ) ;
            MAX_DEPTH = 3 ;
            try {
               MAX_DEPTH = Integer . parseInt ( maxdepthStr ) ;
               if ( MAX_DEPTH == 0 ) {
                  System . out . println ( "La valeur de fjcomp.maxdepth doit etre differente de zero" ) ;
                  System . exit ( 1 ) ;
               }
            }
            catch ( Exception ex ) {
               if ( maxdepthStr == null ) ;
               else {
                  System . out . println ( "La valeur  fjcomp.maxdepth doit etre un entier" ) ;
                  System . exit ( 1 ) ;
               }
            }
            if ( maxdepth >= MAX_DEPTH ) {
               sequentialQuicksort ( a , left , right ) ;
            }
            else {
               if ( left < right ) {
                  int pivotIndex = partition ( a , left , right ) ;
                  sequentialQuicksortImpl task1 = null ;
                  sequentialQuicksortImpl task2 = null ;
                  if ( left < pivotIndex ) task1 = new sequentialQuicksortImpl ( maxdepth + 1 , a , left , pivotIndex ) ;
                  if ( pivotIndex + 1 < right ) task2 = new sequentialQuicksortImpl ( maxdepth + 1 , a , pivotIndex + 1 , right ) ;
                  invokeAll ( task1 , task2 ) ;
               }
            }
         }
         private void sequentialQuicksort ( int [ ] a , int left , int right ) {
            if ( left < right ) {
               int pivotIndex = partition ( a , left , right ) ;
               if ( left < pivotIndex ) sequentialQuicksort ( a , left , pivotIndex ) ;
               if ( pivotIndex + 1 < right ) sequentialQuicksort ( a , pivotIndex + 1 , right ) ;
            }
         }
      }
      public int partition ( int [ ] a , int left , int right ) {
         int pivotValue = a [ middleIndex ( left , right ) ] ;
         -- left ;
         ++ right ;
         while ( true ) {
            do ++ left ;
            while ( a [ left ] < pivotValue ) ;
            do -- right ;
            while ( a [ right ] > pivotValue ) ;
            if ( left < right ) {
               int tmp = a [ left ] ;
               a [ left ] = a [ right ] ;
               a [ right ] = tmp ;
            }
            else {
               return right ;
            }
         }
      }
      private int middleIndex ( int left , int right ) {
         return left + ( right - left ) / 2 ;
      }
   }
   public class MatrixMultiplication {
       int LEAF_SIZE = 512 ;
      public  int [ ] [ ] ijkAlgorithmVector ( Vector < Vector < Integer > > A , Vector < Vector < Integer > > B ) {
         int n = A . size ( ) ;
         int [ ] [ ] C = new int [ n ] [ n ] ;
         for  (int i = 0; i < n; i++) {
            for  (int j = 0; j < n; j++) {
               for  (int k = 0; k < n; k++) {
                  C [ i ] [ j ] += A . get ( i ) . get ( k ) * B . get ( k ) . get ( j ) ;
               }
            }
         }
         return C ;
      }
      public static int [ ] [ ] ijkAlgorithm ( ArrayList < ArrayList < Integer > > A , ArrayList < ArrayList < Integer > > B ) {
         int n = A . size ( ) ;
         int [ ] [ ] C = new int [ n ] [ n ] ;
         for  (int i = 0; i < n; i++) {
            for  (int k = 0; k < n; k++) {
               for  (int j = 0; j < n; j++) {
                  C [ i ] [ j ] += A . get ( i ) . get ( k ) * B . get ( k ) . get ( j ) ;
               }
            }
         }
         return C ;
      }
      public static int [ ] [ ] ikjAlgorithm ( ArrayList < ArrayList < Integer > > A , ArrayList < ArrayList < Integer > > B ) {
         int n = A . size ( ) ;
         int [ ] [ ] C = new int [ n ] [ n ] ;
         for  (int i = 0; i < n; i++) {
            for  (int k = 0; k < n; k++) {
               for  (int j = 0; j < n; j++) {
                  C [ i ] [ j ] += A . get ( i ) . get ( k ) * B . get ( k ) . get ( j ) ;
               }
            }
         }
         return C ;
      }
      public static int [ ] [ ] ikjAlgorithm ( int [ ] [ ] A , int [ ] [ ] B ) {
         int n = A . length ;
         int [ ] [ ] C = new int [ n ] [ n ] ;
         for  (int i = 0; i < n; i++) {
            for  (int k = 0; k < n; k++) {
               for  (int j = 0; j < n; j++) {
                  C [ i ] [ j ] += A [ i ] [ k ] * B [ k ] [ j ] ;
               }
            }
         }
         return C ;
      }
      private static int [ ] [ ] add ( int [ ] [ ] A , int [ ] [ ] B ) {
         int n = A . length ;
         int [ ] [ ] C = new int [ n ] [ n ] ;
         for  (int i = 0; i < n; i++) {
            for  (int j = 0; j < n; j++) {
               C [ i ] [ j ] = A [ i ] [ j ] + B [ i ] [ j ] ;
            }
         }
         return C ;
      }
      private static int [ ] [ ] subtract ( int [ ] [ ] A , int [ ] [ ] B ) {
         int n = A . length ;
         int [ ] [ ] C = new int [ n ] [ n ] ;
         for  (int i = 0; i < n; i++) {
            for  (int j = 0; j < n; j++) {
               C [ i ] [ j ] = A [ i ] [ j ] - B [ i ] [ j ] ;
            }
         }
         return C ;
      }
      private static int nextPowerOfTwo ( int n ) {
         int log2 = ( int ) Math . ceil ( Math . log ( n ) / Math . log ( 2 ) ) ;
         return ( int ) Math . pow ( 2 , log2 ) ;
      }
      public static int [ ] [ ] strassen ( ArrayList < ArrayList < Integer > > A , ArrayList < ArrayList < Integer > > B ) {
         int n = A . size ( ) ;
         int m = nextPowerOfTwo ( n ) ;
         int [ ] [ ] APrep = new int [ m ] [ m ] ;
         int [ ] [ ] BPrep = new int [ m ] [ m ] ;
         for  (int i = 0; i < n; i++) {
            for  (int j = 0; j < n; j++) {
               APrep [ i ] [ j ] = A . get ( i ) . get ( j ) ;
               BPrep [ i ] [ j ] = B . get ( i ) . get ( j ) ;
            }
         }
         int [ ] [ ] CPrep = strassenR ( APrep , BPrep ) ;
         int [ ] [ ] C = new int [ n ] [ n ] ;
         for  (int i = 0; i < n; i++) {
            for  (int j = 0; j < n; j++) {
               C [ i ] [ j ] = CPrep [ i ] [ j ] ;
            }
         }
         return C ;
      }
      private static int [ ] [ ] strassenR ( int [ ] [ ] A , int [ ] [ ] B ) {
         String nbthreadsStr = System . getProperty ( "fjcomp.threads" ) ;
         int numthreads = Runtime . getRuntime ( ) . availableProcessors ( ) ;
         try {
            numthreads = Integer . parseInt ( nbthreadsStr ) ;
            if ( numthreads == 0 ) {
               System . out . println ( "La valeur de fjcomp.threads doit etre differente de zero" ) ;
               System . exit ( 1 ) ;
            }
         }
         catch ( Exception ex ) {
            if ( nbthreadsStr == null ) ;
            else {
               System . out . println ( "La valeur fr fjcomp.threads doit etre un entier" ) ;
               System . exit ( 1 ) ;
            }
         }
         ForkJoinPool pool = new ForkJoinPool ( numthreads ) ;
         strassenRImpl astrassenRImpl = new strassenRImpl ( a , left , right ) ;
         pool . invoke ( astrassenRImpl ) ;
         return astrassenRImpl . result ;
      }
      private static class strassenRImpl extends RecursiveAction {
         private int [ ] a ;
         private int left ;
         private int right ;
         private int [ ] [ ] result ;
         private strassenRImpl ( int [ ] a , int left , int right ) {
            this . a = a ;
            this . left = left ;
            this . right = right ;
         }
         protected void compute ( ) {
            int MAX_DEPTH ;
            String maxdepthStr = System . getProperty ( "fjcomp.maxdepth" ) ;
            try {
               MAX_DEPTH = Integer . parseInt ( maxdepthStr ) ;
               if ( MAX_DEPTH == 0 ) {
                  System . out . println ( "La valeur de fjcomp.maxdepth doit etre differente de zero" ) ;
                  System . exit ( 1 ) ;
               }
            }
            catch ( Exception ex ) {
               if ( maxdepthStr == null ) ;
               else {
                  System . out . println ( "La valeur  fjcomp.maxdepth doit etre un entier" ) ;
                  System . exit ( 1 ) ;
               }
            }
            if ( n < 10 ) {
               result = strassenR ( a , left , right ) ;
            }
            else {
               int n = A . length ;
               if ( n <= LEAF_SIZE ) {
                  result = ikjAlgorithm ( A , B ) ;
               }
               else {
                  int newSize = n / 2 ;
                  int [ ] [ ] a11 = new int [ newSize ] [ newSize ] ;
                  int [ ] [ ] a12 = new int [ newSize ] [ newSize ] ;
                  int [ ] [ ] a21 = new int [ newSize ] [ newSize ] ;
                  int [ ] [ ] a22 = new int [ newSize ] [ newSize ] ;
                  int [ ] [ ] b11 = new int [ newSize ] [ newSize ] ;
                  int [ ] [ ] b12 = new int [ newSize ] [ newSize ] ;
                  int [ ] [ ] b21 = new int [ newSize ] [ newSize ] ;
                  int [ ] [ ] b22 = new int [ newSize ] [ newSize ] ;
                  int [ ] [ ] aResult = new int [ newSize ] [ newSize ] ;
                  int [ ] [ ] bResult = new int [ newSize ] [ newSize ] ;
                  for  (int i = 0; i < newSize; i++) {
                     for  (int j = 0; j < newSize; j++) {
                        a11 [ i ] [ j ] = A [ i ] [ j ] ;
                        a12 [ i ] [ j ] = A [ i ] [ j + newSize ] ;
                        a21 [ i ] [ j ] = A [ i + newSize ] [ j ] ;
                        a22 [ i ] [ j ] = A [ i + newSize ] [ j + newSize ] ;
                        b11 [ i ] [ j ] = B [ i ] [ j ] ;
                        b12 [ i ] [ j ] = B [ i ] [ j + newSize ] ;
                        b21 [ i ] [ j ] = B [ i + newSize ] [ j ] ;
                        b22 [ i ] [ j ] = B [ i + newSize ] [ j + newSize ] ;
                     }
                  }
                  strassenRImpl task1 = null ;
                  strassenRImpl task2 = null ;
                  strassenRImpl task3 = null ;
                  strassenRImpl task4 = null ;
                  strassenRImpl task5 = null ;
                  strassenRImpl task6 = null ;
                  strassenRImpl task7 = null ;
                  aResult = add ( a11 , a22 ) ;
                  bResult = add ( b11 , b22 ) ;
                  int [ ] [ ] p1 ;
                  task1 = new strassenRImpl ( aResult , bResult ) ;
                  aResult = add ( a21 , a22 ) ;
                  int [ ] [ ] p2 ;
                  task2 = new strassenRImpl ( aResult , b11 ) ;
                  bResult = subtract ( b12 , b22 ) ;
                  int [ ] [ ] p3 ;
                  task3 = new strassenRImpl ( a11 , bResult ) ;
                  bResult = subtract ( b21 , b11 ) ;
                  int [ ] [ ] p4 ;
                  task4 = new strassenRImpl ( a22 , bResult ) ;
                  aResult = add ( a11 , a12 ) ;
                  int [ ] [ ] p5 ;
                  task5 = new strassenRImpl ( aResult , b22 ) ;
                  aResult = subtract ( a21 , a11 ) ;
                  bResult = add ( b11 , b12 ) ;
                  int [ ] [ ] p6 ;
                  task6 = new strassenRImpl ( aResult , bResult ) ;
                  aResult = subtract ( a12 , a22 ) ;
                  bResult = add ( b21 , b22 ) ;
                  int [ ] [ ] p7 ;
                  task7 = new strassenRImpl ( aResult , bResult ) ;
                  invokeAll ( task1 , task2 , task3 , task4 , task5 , task6 , task7 ) ;
                  p1 = task1 . result ;
                  p2 = task2 . result ;
                  p3 = task3 . result ;
                  p4 = task4 . result ;
                  p5 = task5 . result ;
                  p6 = task6 . result ;
                  p7 = task7 . result ;
                  int [ ] [ ] c12 = add ( p3 , p5 ) ;
                  int [ ] [ ] c21 = add ( p2 , p4 ) ;
                  aResult = add ( p1 , p4 ) ;
                  bResult = add ( aResult , p7 ) ;
                  int [ ] [ ] c11 = subtract ( bResult , p5 ) ;
                  aResult = add ( p1 , p3 ) ;
                  bResult = add ( aResult , p6 ) ;
                  int [ ] [ ] c22 = subtract ( bResult , p2 ) ;
                  int [ ] [ ] C = new int [ n ] [ n ] ;
                  for  (int i = 0; i < newSize; i++) {
                     for  (int j = 0; j < newSize; j++) {
                        C [ i ] [ j ] = c11 [ i ] [ j ] ;
                        C [ i ] [ j + newSize ] = c12 [ i ] [ j ] ;
                        C [ i + newSize ] [ j ] = c21 [ i ] [ j ] ;
                        C [ i + newSize ] [ j + newSize ] = c22 [ i ] [ j ] ;
                     }
                  }
                  result = C ;
               }
            }
         }
         private int [ ] [ ] strassenR ( int [ ] [ ] A , int [ ] [ ] B ) {
            int n = A . length ;
            if ( n <= LEAF_SIZE ) {
               return ikjAlgorithm ( A , B ) ;
            }
            else {
               int newSize = n / 2 ;
               int [ ] [ ] a11 = new int [ newSize ] [ newSize ] ;
               int [ ] [ ] a12 = new int [ newSize ] [ newSize ] ;
               int [ ] [ ] a21 = new int [ newSize ] [ newSize ] ;
               int [ ] [ ] a22 = new int [ newSize ] [ newSize ] ;
               int [ ] [ ] b11 = new int [ newSize ] [ newSize ] ;
               int [ ] [ ] b12 = new int [ newSize ] [ newSize ] ;
               int [ ] [ ] b21 = new int [ newSize ] [ newSize ] ;
               int [ ] [ ] b22 = new int [ newSize ] [ newSize ] ;
               int [ ] [ ] aResult = new int [ newSize ] [ newSize ] ;
               int [ ] [ ] bResult = new int [ newSize ] [ newSize ] ;
               for  (int i = 0; i < newSize; i++) {
                  for  (int j = 0; j < newSize; j++) {
                     a11 [ i ] [ j ] = A [ i ] [ j ] ;
                     a12 [ i ] [ j ] = A [ i ] [ j + newSize ] ;
                     a21 [ i ] [ j ] = A [ i + newSize ] [ j ] ;
                     a22 [ i ] [ j ] = A [ i + newSize ] [ j + newSize ] ;
                     b11 [ i ] [ j ] = B [ i ] [ j ] ;
                     b12 [ i ] [ j ] = B [ i ] [ j + newSize ] ;
                     b21 [ i ] [ j ] = B [ i + newSize ] [ j ] ;
                     b22 [ i ] [ j ] = B [ i + newSize ] [ j + newSize ] ;
                  }
               }
               aResult = add ( a11 , a22 ) ;
               bResult = add ( b11 , b22 ) ;
               int [ ] [ ] p1 ;
               p1 = strassenR ( aResult , bResult ) ;
               aResult = add ( a21 , a22 ) ;
               int [ ] [ ] p2 ;
               p2 = strassenR ( aResult , b11 ) ;
               bResult = subtract ( b12 , b22 ) ;
               int [ ] [ ] p3 ;
               p3 = strassenR ( a11 , bResult ) ;
               bResult = subtract ( b21 , b11 ) ;
               int [ ] [ ] p4 ;
               p4 = strassenR ( a22 , bResult ) ;
               aResult = add ( a11 , a12 ) ;
               int [ ] [ ] p5 ;
               p5 = strassenR ( aResult , b22 ) ;
               aResult = subtract ( a21 , a11 ) ;
               bResult = add ( b11 , b12 ) ;
               int [ ] [ ] p6 ;
               p6 = strassenR ( aResult , bResult ) ;
               aResult = subtract ( a12 , a22 ) ;
               bResult = add ( b21 , b22 ) ;
               int [ ] [ ] p7 ;
               p7 = strassenR ( aResult , bResult ) ;
               int [ ] [ ] c12 = add ( p3 , p5 ) ;
               int [ ] [ ] c21 = add ( p2 , p4 ) ;
               aResult = add ( p1 , p4 ) ;
               bResult = add ( aResult , p7 ) ;
               int [ ] [ ] c11 = subtract ( bResult , p5 ) ;
               aResult = add ( p1 , p3 ) ;
               bResult = add ( aResult , p6 ) ;
               int [ ] [ ] c22 = subtract ( bResult , p2 ) ;
               int [ ] [ ] C = new int [ n ] [ n ] ;
               for  (int i = 0; i < newSize; i++) {
                  for  (int j = 0; j < newSize; j++) {
                     C [ i ] [ j ] = c11 [ i ] [ j ] ;
                     C [ i ] [ j + newSize ] = c12 [ i ] [ j ] ;
                     C [ i + newSize ] [ j ] = c21 [ i ] [ j ] ;
                     C [ i + newSize ] [ j + newSize ] = c22 [ i ] [ j ] ;
                  }
               }
               return C ;
            }
         }
      }
      public static void main ( String args [ ] ) {
         int N = 4096 ;
         int [ ] [ ] result_ = new int [ N ] [ N ] ;
         int [ ] [ ] a = new int [ N ] [ N ] ;
         for (int i=0;i<N;i++) for (int j=0;j<N;j++) {
            a [ i ] [ j ] = 5 ;
         }
         StopWatch stopWatch = new StopWatch ( ) ;
         int [ ] [ ] result1 = strassenR ( a , a ) ;
         stopWatch . stop ( ) ;
         System . out . println ( "Sequential Matrix Product Elapsed Time: " + stopWatch . getElapsedTime ( ) ) ;
      }
   }
}
 