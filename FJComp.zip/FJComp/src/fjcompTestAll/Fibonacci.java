/*************************************************************************
*   Ce code est g�n�r� et mis en forme par le compilateur FJComp         *
* Auteur du Compilateur: Abdourahmane Senghor  -- boya2senghor@yahoo.fr  *
**************************************************************************/


package fjcompTestAll ;
import java . util . concurrent . ForkJoinPool ;
import java . util . concurrent . RecursiveAction ;
public class Fibonacci {
   public long fibonacci ( int n ) {
      String nbthreadsStr = System . getProperty ( "fjcomp.threads" ) ;
      int numthreads = Runtime . getRuntime ( ) . availableProcessors ( ) ;
      try {
         numthreads = Integer . parseInt ( nbthreadsStr ) ;
         if ( numthreads == 0 ) {
            System . out . println ( "La valeur de fjcomp.threads doit etre differente de zero" ) ;
            System . exit ( 1 ) ;
         }
      }
      catch ( Exception ex ) {
         if ( nbthreadsStr == null ) ;
         else {
            System . out . println ( "La valeur fr fjcomp.threads doit etre un entier" ) ;
            System . exit ( 1 ) ;
         }
      }
      ForkJoinPool pool = new ForkJoinPool ( numthreads ) ;
      fibonacciImpl afibonacciImpl = new fibonacciImpl ( n ) ;
      pool . invoke ( afibonacciImpl ) ;
      return afibonacciImpl . result ;
   }
   private class fibonacciImpl extends RecursiveAction {
      private int n ;
      private long result ;
      private fibonacciImpl ( int n ) {
         this . n = n ;
      }
      protected void compute ( ) {
         int MAX_DEPTH ;
         String maxdepthStr = System . getProperty ( "fjcomp.maxdepth" ) ;
         try {
            MAX_DEPTH = Integer . parseInt ( maxdepthStr ) ;
            if ( MAX_DEPTH == 0 ) {
               System . out . println ( "La valeur de fjcomp.maxdepth doit etre differente de zero" ) ;
               System . exit ( 1 ) ;
            }
         }
         catch ( Exception ex ) {
            if ( maxdepthStr == null ) ;
            else {
               System . out . println ( "La valeur  fjcomp.maxdepth doit etre un entier" ) ;
               System . exit ( 1 ) ;
            }
         }
         if ( n < 10 ) {
            result = fibonacci ( n ) ;
         }
         else {
            if ( n == 0 ) {
               result = 0 ;
            }
            if ( n == 1 ) {
               result = 1 ;
            }
            long x , y ;
            fibonacciImpl task1 = null ;
            fibonacciImpl task2 = null ;
            task1 = new fibonacciImpl ( n - 1 ) ;
            task2 = new fibonacciImpl ( n - 2 ) ;
            invokeAll ( task1 , task2 ) ;
            x = task1 . result ;
            y = task2 . result ;
            result = x + y ;
         }
      }
      private long fibonacci ( int n ) {
         if ( n == 0 ) {
            return 0 ;
         }
         if ( n == 1 ) {
            return 1 ;
         }
         long x , y ;
         x = fibonacci ( n - 1 ) ;
         y = fibonacci ( n - 2 ) ;
         return x + y ;
      }
   }
   public static void main(String args[]){}
}
 