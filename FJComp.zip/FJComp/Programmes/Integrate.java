/*************************************************************************
*   Ce code est g�n�r� et mis en forme par le compilateur FJComp         *
* Auteur du Compilateur: Abdourahmane Senghor  -- boya2senghor@yahoo.fr  *
**************************************************************************/


package fjcompTestAll ;
import java . util . concurrent . ForkJoinPool ;
import java . util . concurrent . RecursiveAction ;
public class Integrate {
   static interface Function {
      double compute ( double x ) ;
   }
   static class SampleFunction implements Function {
      final int n ;
      SampleFunction ( int n ) {
         this . n = n ;
      }
      public double compute ( double x ) {
         double power = x ;
         double xsq = x * x ;
         double val = power ;
         double di = 1.0 ;
         for  (int i = n - 1; i > 0; --i) {
            di += 2.0 ;
            power *= xsq ;
            val += di * power ;
         }
         return val ;
      }
   }
   static class Integrator {
      final Function f ;
      final double errorTolerance ;
      Integrator ( Function f , double errorTolerance ) {
         this . f = f ;
         this . errorTolerance = errorTolerance ;
      }
      double integral ( double lowerBound , double upperBound ) {
         double f_lower = f . compute ( lowerBound ) ;
         double f_upper = f . compute ( upperBound ) ;
         double initialArea = 0.5 * ( upperBound - lowerBound ) * ( f_upper + f_lower ) ;
         Quad q = new Quad ( f , errorTolerance ) ;
         return q . run ( lowerBound , upperBound , f_lower , f_upper , initialArea ) ;
      }
      static class Quad {
         final Function f ;
         final double errorTolerance ;
         Quad ( Function f , double errorTolerance ) {
            this . f = f ;
            this . errorTolerance = errorTolerance ;
         }
         public double run ( double left , double right , double f_left , double f_right , double area ) {
            String nbthreadsStr = System . getProperty ( "fjcomp.threads" ) ;
            int numthreads = 2 ;
            try {
               numthreads = Integer . parseInt ( nbthreadsStr ) ;
               if ( numthreads == 0 ) {
                  System . out . println ( "La valeur de fjcomp.threads doit etre differente de zero" ) ;
                  System . exit ( 1 ) ;
               }
            }
            catch ( Exception ex ) {
               if ( nbthreadsStr == null ) ;
               else {
                  System . out . println ( "La valeur fr fjcomp.threads doit etre un entier" ) ;
                  System . exit ( 1 ) ;
               }
            }
            ForkJoinPool pool = new ForkJoinPool ( numthreads ) ;
            runImpl arunImpl = new runImpl ( 0 , left , right , f_left , f_right , area ) ;
            pool . invoke ( arunImpl ) ;
            return arunImpl . result ;
         }
         private class runImpl extends RecursiveAction {
            private int maxdepth ;
            private double left ;
            private double right ;
            private double f_left ;
            private double f_right ;
            private double area ;
            private double result ;
            private runImpl ( int maxdepth , double left , double right , double f_left , double f_right , double area ) {
               this . maxdepth = maxdepth ;
               this . left = left ;
               this . right = right ;
               this . f_left = f_left ;
               this . f_right = f_right ;
               this . area = area ;
            }
            protected void compute ( ) {
               int MAX_DEPTH ;
               String maxdepthStr = System . getProperty ( "fjcomp.maxdepth" ) ;
               MAX_DEPTH = 4 ;
               try {
                  MAX_DEPTH = Integer . parseInt ( maxdepthStr ) ;
                  if ( MAX_DEPTH == 0 ) {
                     System . out . println ( "La valeur de fjcomp.maxdepth doit etre differente de zero" ) ;
                     System . exit ( 1 ) ;
                  }
               }
               catch ( Exception ex ) {
                  if ( maxdepthStr == null ) ;
                  else {
                     System . out . println ( "La valeur  fjcomp.maxdepth doit etre un entier" ) ;
                     System . exit ( 1 ) ;
                  }
               }
               if ( maxdepth >= MAX_DEPTH ) {
                  result = run ( left , right , f_left , f_right , area ) ;
               }
               else {
                  double center = 0.5 * ( left + right ) ;
                  double f_center = f . compute ( center ) ;
                  double leftArea = 0.5 * ( center - left ) * ( f_left + f_center ) ;
                  double rightArea = 0.5 * ( right - center ) * ( f_center + f_right ) ;
                  double sum = leftArea + rightArea ;
                  double diff = sum - area ;
                  if ( diff < 0 ) diff = - diff ;
                  if ( diff >= errorTolerance ) {
                     double q1 ;
                     double q2 ;
                     runImpl task1 = null ;
                     runImpl task2 = null ;
                     task1 = new runImpl ( maxdepth + 1 , left , center , f_left , f_center , leftArea ) ;
                     task2 = new runImpl ( maxdepth + 1 , center , right , f_center , f_right , rightArea ) ;
                     invokeAll ( task1 , task2 ) ;
                     q1 = task1 . result ;
                     q2 = task2 . result ;
                     sum = q1 + q2 ;
                  }
                  result = sum ;
               }
            }
            private double run ( double left , double right , double f_left , double f_right , double area ) {
               double center = 0.5 * ( left + right ) ;
               double f_center = f . compute ( center ) ;
               double leftArea = 0.5 * ( center - left ) * ( f_left + f_center ) ;
               double rightArea = 0.5 * ( right - center ) * ( f_center + f_right ) ;
               double sum = leftArea + rightArea ;
               double diff = sum - area ;
               if ( diff < 0 ) diff = - diff ;
               if ( diff >= errorTolerance ) {
                  double q1 ;
                  double q2 ;
                  q1 = run ( left , center , f_left , f_center , leftArea ) ;
                  q2 = run ( center , right , f_center , f_right , rightArea ) ;
                  sum = q1 + q2 ;
               }
               return sum ;
            }
         }
      }
   }
}
 