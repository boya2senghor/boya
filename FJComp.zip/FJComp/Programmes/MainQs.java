/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fjcompTestAll;
//import ForkJoin.*;


/**
 *
 * @author Administrateur
 */
public class MainQs {
    public static void main(String[] args) {


                int N= Integer.parseInt(args[0]);
       // int N=20000000;
		// Check the number of available processors
		//int processors = Runtime.getRuntime().availableProcessors();
		//System.out.println("No of processors: " + processors);
                //int n=Integer.parseInt(args[0]);

                java.util.Random generator=new java.util.Random(1101979);
               // final int N = 200000000;
                int a[]=new int[N];
                for(int i=0;i<N;i++) a[i]=generator.nextInt(400000000);

                //Sequentila Execution
                StopWatch stopWatch = new StopWatch();
		QS bigProblem = new QS(a,0,a.length-1);

		bigProblem.sequentialQuicksort(a,0,a.length-1);

		stopWatch.stop();

		testQS(a);
                //for(int i=0;i<a.length;i++) System.out.println(a[i]);
		System.out.println("Sequential QS Elapsed Time: " + stopWatch.getElapsedTime());

               


	}

        public static void testQS(int numbers[]) {

		for (int i = 0; i < numbers.length - 1; i++) {
			if (numbers[i] > numbers[i + 1]) {
				//fail("Should not happen");
                                System.out.println("faild");
                                System.exit(1);
			}
		}
		//assertTrue(true);
                System.out.println("successfull");
	}


}
