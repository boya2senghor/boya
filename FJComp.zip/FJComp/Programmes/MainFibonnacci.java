/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Programmes;

//import Concurrencer.*;

/**
 *
 * @author Administrateur
 */
public class MainFibonnacci {


    public static void main(String args[]){

                int n=Integer.parseInt(args[0]);
                 //int n=45;
                //Sequential Execution
                StopWatch stopWatch = new StopWatch();		
                
		stopWatch.stop();

		//System.out.println("Sequential Fibonacci Computed Result: " + result);
		System.out.println("Sequential Fibonacci Elapsed Time: " + stopWatch.getElapsedTime());

                //ForkJoin Execution

		StopWatch stopWatch1 = new StopWatch();
		Fibonacci Fib=new Fibonacci();
		long result1=Fib.fibonacci(n);                 
                stopWatch1.stop();
		System.out.println("ForkJoin Fibonacci Computed Result: " + result1);
		System.out.println("ForkJoin Fibonacci Elapsed Time: " + stopWatch1.getElapsedTime());

                //javar Execution           
        
    }

}
