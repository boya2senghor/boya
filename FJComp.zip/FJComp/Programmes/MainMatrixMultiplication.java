/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fjcompTestAll;

/**
 *
 * @author zing
 */

public class MainMatrixMultiplication {
      public static void main(String args[]){
      //  int N=16;
       int N=Integer.parseInt(args[0]);
         int[][] result_=new int[N][N];
         int[][] a=new int[N][N];

       // DivConqMatrixMulti m=new DivConqMatrixMulti(N);


         for(int i=0;i<N;i++)
                    for(int j=0;j<N;j++){
                        a[i][j]=5;
                    }
         StopWatch stopWatch = new StopWatch();

        int[][] result1=MatrixMultiplication.strassenR(a, a);
        stopWatch.stop();
         System.out.println("Sequential Matrix Product Elapsed Time: " + stopWatch.getElapsedTime());

        /*
         System.out.println("Matrix = ");
		for (int i = 0; i < N; i++)
			for (int j = 0; j < N; j++)
			{
				System.out.print(result1[i][j] + " ");
				if (j == (N-1))
					System.out.println();
			}
         * */




    }
}
