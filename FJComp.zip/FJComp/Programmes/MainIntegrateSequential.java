/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package fjcompTestAll;

/**
 *
 * @author Administrateur
 */
public class MainIntegrateSequential {
     public static void main(String[] args) {
         double start = -47;
         double end = 48;

          StopWatch stopWatch = new StopWatch();

         Integrate.Function f = new Integrate.SampleFunction(6);
         Integrate.Integrator integrator = new Integrate.Integrator(f, 0.001);

         double result = integrator.integral(start, end);

         stopWatch.stop();

        System.out.println("Answer = " + result);
        System.out.println("Integrate elapsed time: " + stopWatch.getElapsedTime());
     }

}
